<?php $__env->startSection('title', 'Privacy Policy'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h1>Privacy Policy</h1>
  <p class="text-muted">Last updated: <?php echo e(date('Y')); ?></p>
  <p>This is a placeholder for your Privacy Policy. You can manage this content later via the CMS or by editing this file.</p>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/privacy.blade.php ENDPATH**/ ?>