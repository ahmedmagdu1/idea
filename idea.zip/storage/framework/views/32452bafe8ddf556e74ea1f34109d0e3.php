<?php $__env->startSection('title', 'Careers Management'); ?>
<?php $__env->startSection('page-title', 'Careers'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4">Careers</h1>
    <a href="<?php echo e(route('admin.careers.create')); ?>" class="btn btn-brand">New</a>
  </div>
  <table class="table table-striped">
    <thead><tr><th>Title</th><th>Location</th><th>Status</th><th>Published</th><th></th></tr></thead>
    <tbody>
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($it->title); ?></td>
          <td><?php echo e($it->location); ?></td>
          <td><?php echo e($it->is_published ? 'Published' : 'Draft'); ?></td>
          <td><?php echo e(optional($it->published_at)->format('Y-m-d')); ?></td>
          <td class="text-end">
            <a href="<?php echo e(route('admin.careers.edit', $it)); ?>" class="btn btn-sm btn-secondary">Edit</a>
            <form action="<?php echo e(route('admin.careers.destroy', $it)); ?>" method="post" class="d-inline" onsubmit="return confirm('Delete?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($items->links()); ?>

  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/admin/careers/index.blade.php ENDPATH**/ ?>