<?php $__env->startSection('title', 'Press Management'); ?>
<?php $__env->startSection('page-title', $item->exists ? 'Edit Post' : 'New Post'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <h1 class="h4 mb-3"><?php echo e($item->exists ? 'Edit Post' : 'New Post'); ?></h1>
  <form method="post" action="<?php echo e($item->exists ? route('admin.press.update', $item) : route('admin.press.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if($item->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="row g-3">
      <div class="col-md-8">
        <label class="form-label">Title</label>
        <input name="title" class="form-control" value="<?php echo e(old('title', $item->title)); ?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">Slug</label>
        <input name="slug" class="form-control" value="<?php echo e(old('slug', $item->slug)); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Published at</label>
        <input type="datetime-local" name="published_at" class="form-control" value="<?php echo e(old('published_at', optional($item->published_at)->format('Y-m-d\TH:i'))); ?>">
      </div>
      <div class="col-12">
        <label class="form-label">Excerpt</label>
        <textarea name="excerpt" class="form-control" rows="3"><?php echo e(old('excerpt', $item->excerpt)); ?></textarea>
      </div>
      <div class="col-md-6">
        <label class="form-label">Image</label>
        <input type="file" name="image" class="form-control">
        <?php if($item->image): ?>
          <div class="mt-2">
            <img src="/<?php echo e($item->image); ?>" alt="Image" style="max-height:120px" class="img-thumbnail">
          </div>
        <?php endif; ?>
      </div>
      <div class="col-12">
        <label class="form-label">Body</label>
        <textarea name="body" class="form-control" rows="8"><?php echo e(old('body', $item->body)); ?></textarea>
      </div>
      <div class="col-12 form-check mt-2">
        <input type="checkbox" name="is_published" value="1" class="form-check-input" id="is_pub" <?php echo e(old('is_published', $item->is_published) ? 'checked' : ''); ?>>
        <label class="form-check-label" for="is_pub">Published</label>
      </div>
      <div class="col-12 mt-3">
        <button class="btn btn-brand">Save</button>
        <a href="<?php echo e(route('admin.press.index')); ?>" class="btn btn-link">Cancel</a>
      </div>
    </div>
  </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/admin/press/form.blade.php ENDPATH**/ ?>