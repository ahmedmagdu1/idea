<?php $__env->startSection('title', $item->title); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <a href="<?php echo e(url('/press')); ?>" class="text-decoration-none">&larr; Back to Press</a>
  <div class="row mt-3">
    <div class="col-lg-8">
      <h1 class="mb-1"><?php echo e($item->title); ?></h1>
      <div class="text-muted mb-3"><?php echo e(optional($item->published_at)->format('M d, Y')); ?></div>
      <article class="mb-4"><?php echo nl2br(e($item->body)); ?></article>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/press/show.blade.php ENDPATH**/ ?>