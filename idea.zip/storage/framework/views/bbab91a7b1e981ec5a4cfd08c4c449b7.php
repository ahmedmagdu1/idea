<?php $__env->startSection('title', 'Press Management'); ?>
<?php $__env->startSection('page-title', 'Press / Blog'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4">Press / Blog</h1>
    <a href="<?php echo e(route('admin.press.create')); ?>" class="btn btn-brand">New</a>
  </div>
  <table class="table table-striped">
    <thead><tr><th>Title</th><th>Status</th><th>Published</th><th></th></tr></thead>
    <tbody>
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($it->title); ?></td>
          <td><?php echo e($it->is_published ? 'Published' : 'Draft'); ?></td>
          <td><?php echo e(optional($it->published_at)->format('Y-m-d')); ?></td>
          <td class="text-end">
            <a href="<?php echo e(route('admin.press.edit', $it)); ?>" class="btn btn-sm btn-secondary">Edit</a>
            <form action="<?php echo e(route('admin.press.destroy', $it)); ?>" method="post" class="d-inline" onsubmit="return confirm('Delete?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($items->links()); ?>

  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/admin/press/index.blade.php ENDPATH**/ ?>