<?php

return array (
  'aboutus_title' => 'aboutus_title',
  'aboutus_lead' => 'aboutus_lead',
  'aboutus_tab1' => 'aboutus_tab1',
  'aboutus_tab2' => 'aboutus_tab2',
  'aboutus_tab3' => 'aboutus_tab3',
  'case_title' => 'case_title',
  'case_desc' => 'case_desc',
  'case_btn' => 'case_btn',
);
