<?php

return array (
  'aboutus_title' => 'aboutus_title',
  'aboutus_lead' => 'aboutus_lead',
  'our_services' => 'our_services',
  'btn_readmore' => 'btn_readmore',
  'btn_contact' => 'btn_contact',
  'btn_learnmore' => 'btn_learnmore',
);
