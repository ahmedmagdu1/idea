 
<?php $__env->startSection('page-title','إدارة الفريق'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-body d-flex justify-content-between align-items-center">
        <h5 class="mb-0">أعضاء الفريق</h5>
        <a href="<?php echo e(route('admin.team.create')); ?>" class="btn btn-primary">
            <i class="fa fa-plus ms-1"></i> إضافة عضو
        </a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>الصورة</th>
                    <th>الاسم</th>
                    <th>الوظيفة</th>
                    <th>القسم</th>
                    <th>البريد</th>
                    <th>الترتيب</th>
                    <th>الحالة</th>
                    <th class="text-center">إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($m->id); ?></td>
                    <td>
                        <img src="<?php echo e($m->photo_url); ?>" style="width:48px;height:48px;object-fit:cover;border-radius:8px">
                    </td>
                    <td><?php echo e($m->name); ?></td>
                    <td><?php echo e($m->title); ?></td>
                    <td><?php echo e($m->department); ?></td>
                    <td><a href="mailto:<?php echo e($m->email); ?>"><?php echo e($m->email); ?></a></td>
                    <td><?php echo e($m->sort_order); ?></td>
                    <td>
                        <span class="badge <?php echo e($m->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                            <?php echo e($m->is_active ? 'مفعل' : 'غير مفعل'); ?>

                        </span>
                    </td>
                    <td class="text-center">
                        <a href="<?php echo e(route('admin.team.edit',$m)); ?>" class="btn btn-sm btn-outline-primary">تعديل</a>
                        <form action="<?php echo e(route('admin.team.destroy',$m)); ?>" method="POST" class="d-inline"
                              onsubmit="return confirm('تأكيد الحذف؟');">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger">حذف</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="9" class="text-center py-4">لا توجد بيانات حالياً</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-body">
        <?php echo e($members->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
س
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/admin/team/index.blade.php ENDPATH**/ ?>