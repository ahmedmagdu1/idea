

<?php $__env->startSection('title', 'تحرير ' . $page); ?>
<?php $__env->startSection('page-title', 'تحرير محتوى صفحة ' . ucfirst($page)); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-3">
        <div class="btn-group">
            <a href="<?php echo e(route('admin.content.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-right me-2"></i>
                العودة
            </a>
            <form method="POST" action="<?php echo e(route('admin.content.scan-page', $page)); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-info">
                    <i class="fas fa-sync-alt me-2"></i>
                    فحص الصفحة
                </button>
            </form>
        </div>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle me-2"></i>
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- تحرير النصوص -->
<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">
            <i class="fas fa-font me-2"></i>
            النصوص والترجمات (<?php echo e(count($translations['ar'] ?? [])); ?> عنصر)
        </h5>
    </div>
    <div class="card-body">
        <?php if(!empty($translations['ar']) || !empty($translations['en'])): ?>
            <form method="POST" action="<?php echo e(route('admin.content.update-translations', $page)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th width="20%">
                                    <i class="fas fa-key me-2"></i>
                                    المفتاح
                                </th>
                                <th width="40%">
                                    <i class="fas fa-flag me-2"></i>
                                    العربية
                                </th>
                                <th width="40%">
                                    <i class="fas fa-flag me-2"></i>
                                    English
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $allKeys = array_unique(array_merge(
                                    array_keys($translations['ar'] ?? []), 
                                    array_keys($translations['en'] ?? [])
                                ));
                                sort($allKeys);
                            ?>
                            
                            <?php $__currentLoopData = $allKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <code class="text-primary"><?php echo e($key); ?></code>
                                    </td>
                                    <td>
                                        <textarea name="ar[<?php echo e($key); ?>]" 
                                                class="form-control auto-resize" 
                                                rows="1"
                                                placeholder="أدخل النص بالعربية"><?php echo e($translations['ar'][$key] ?? ''); ?></textarea>
                                    </td>
                                    <td>
                                        <textarea name="en[<?php echo e($key); ?>]" 
                                                class="form-control auto-resize" 
                                                rows="1"
                                                placeholder="Enter text in English"><?php echo e($translations['en'][$key] ?? ''); ?></textarea>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="text-center mt-3">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save me-2"></i>
                        حفظ جميع النصوص
                    </button>
                </div>
            </form>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                لا توجد نصوص متاحة. قم بفحص الصفحة لاستخراج النصوص تلقائياً.
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- تحرير الصور -->
<div class="card">
    <div class="card-header bg-success text-white">
        <h5 class="mb-0">
            <i class="fas fa-images me-2"></i>
            الصور (<?php echo e(count($images)); ?> صورة)
        </h5>
    </div>
    <div class="card-body">
        <div class="row" id="images-container">
            <!-- صور موجودة -->
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $imagePath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4" id="image_container_<?php echo e($key); ?>">
                    <div class="card shadow-sm">
                        <div class="position-relative">
                            <img src="<?php echo e($imagePath); ?>" 
                                 class="card-img-top" 
                                 style="height: 200px; object-fit: cover;" 
                                 id="preview_<?php echo e($key); ?>"
                                 alt="<?php echo e($key); ?>">
                            <div class="position-absolute top-0 end-0 p-2">
                                <button type="button" 
                                        class="btn btn-danger btn-sm rounded-circle delete-image-btn"
                                        data-key="<?php echo e($key); ?>"
                                        title="حذف الصورة">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <h6 class="card-title text-primary">
                                <i class="fas fa-image me-2"></i>
                                <?php echo e($key); ?>

                            </h6>
                            <div class="mb-2">
                                <small class="text-muted"><?php echo e($imagePath); ?></small>
                            </div>
                            <input type="file" 
                                   class="form-control form-control-sm image-upload" 
                                   data-key="<?php echo e($key); ?>"
                                   accept="image/*">
                            <div class="mt-2">
                                <div class="progress d-none" id="progress_<?php echo e($key); ?>">
                                    <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <!-- إضافة صورة جديدة -->
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card border-2 border-dashed border-primary h-100" style="min-height: 350px;">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center text-center">
                        <div class="mb-3">
                            <i class="fas fa-cloud-upload-alt fa-4x text-primary opacity-50"></i>
                        </div>
                        <h6 class="text-primary">إضافة صورة جديدة</h6>
                        <p class="text-muted small">سيتم إضافتها لقائمة صور الصفحة</p>
                        <div class="w-100">
                            <input type="text" 
                                   class="form-control form-control-sm mb-3" 
                                   id="new-image-key" 
                                   placeholder="اسم الصورة (مثل: hero_banner)">
                            <input type="file" 
                                   class="form-control form-control-sm" 
                                   id="new-image-upload"
                                   accept="image/*">
                            <div class="mt-2">
                                <div class="progress d-none" id="progress_new">
                                    <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // تلقائي تعديل حجم textarea
    document.querySelectorAll('.auto-resize').forEach(function(textarea) {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    });

    // رفع الصور الموجودة
    document.querySelectorAll('.image-upload').forEach(function(input) {
        input.addEventListener('change', function() {
            uploadImage(this.files[0], this.dataset.key, this);
        });
    });

    // رفع صورة جديدة
    document.getElementById('new-image-upload').addEventListener('change', function() {
        const key = document.getElementById('new-image-key').value.trim();
        if (!key) {
            showAlert('يرجى إدخال اسم للصورة', 'warning');
            return;
        }
        uploadImage(this.files[0], key, this, true);
    });

    // حذف الصور
    document.querySelectorAll('.delete-image-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const key = this.dataset.key;
            if (confirm('هل أنت متأكد من حذف هذه الصورة؟')) {
                deleteImage(key);
            }
        });
    });

    function uploadImage(file, key, input, isNew = false) {
        const formData = new FormData();
        formData.append('image', file);
        formData.append('image_key', key);
        formData.append('page', '<?php echo e($page); ?>');
        formData.append('_token', '<?php echo e(csrf_token()); ?>');

        // إظهار شريط التقدم
        const progressBar = document.getElementById(`progress_${isNew ? 'new' : key}`);
        const progressBarInner = progressBar.querySelector('.progress-bar');
        progressBar.classList.remove('d-none');

        fetch('<?php echo e(route("admin.content.upload-image")); ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            progressBar.classList.add('d-none');
            
            if (data.success) {
                if (isNew) {
                    location.reload();
                } else {
                    document.getElementById('preview_' + key).src = data.image_url + '?t=' + Date.now();
                    showAlert(data.message || 'تم رفع الصورة بنجاح', 'success');
                }
            } else {
                showAlert(data.message || 'حدث خطأ في رفع الصورة', 'danger');
            }
        })
        .catch(error => {
            progressBar.classList.add('d-none');
            console.error('Error:', error);
            showAlert('حدث خطأ في رفع الصورة', 'danger');
        });
    }

    function deleteImage(key) {
        const formData = new FormData();
        formData.append('key', key);
        formData.append('page', '<?php echo e($page); ?>');
        formData.append('_token', '<?php echo e(csrf_token()); ?>');

        fetch('<?php echo e(route("admin.content.delete-image")); ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('image_container_' + key).remove();
                showAlert(data.message || 'تم حذف الصورة بنجاح', 'success');
            } else {
                showAlert(data.message || 'فشل في حذف الصورة', 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('حدث خطأ في حذف الصورة', 'danger');
        });
    }

    function showAlert(message, type) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check' : type === 'warning' ? 'exclamation-triangle' : 'exclamation'}-circle me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.querySelector('.content').insertBefore(alertDiv, document.querySelector('.content').firstChild);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
});
</script>

<style>
.border-dashed {
    border-style: dashed !important;
    transition: all 0.3s ease;
}
.border-dashed:hover {
    border-color: #0d6efd !important;
    background-color: rgba(13, 110, 253, 0.05);
}
.auto-resize {
    resize: none;
    overflow: hidden;
}
code {
    font-size: 0.9em;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/admin/simple-content/edit.blade.php ENDPATH**/ ?>