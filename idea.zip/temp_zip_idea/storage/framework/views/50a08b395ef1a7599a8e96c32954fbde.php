<?php $__env->startSection('title', __('messages.welcome')); ?>

<?php $__env->startSection('content'); ?>

<section class="aboutus-hero position-relative">
    <img src="<?php echo e(asset('images/about-hero.png')); ?>" class="aboutus-bg-img" alt="">
    <div class="aboutus-overlay"></div>
    <div class="container h-100 d-flex flex-column justify-content-center align-items-center text-center aboutus-hero-content">
        <h2 class="aboutus-title mb-2"><?php echo e(__('main.aboutus_title')); ?></h2>
        <div class="aboutus-lead"><?php echo e(__('main.aboutus_lead')); ?></div>
    </div>
</section>




<!-- Swiper CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

<div class="client-logos-section py-3" style="background: #fff;">
    <div class="container">
        <div class="swiper client-logos-swiper">
            <div class="swiper-wrapper align-items-center">
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/chery.png')); ?>" alt="Chery" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/lexus.png')); ?>" alt="Lexus" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/rasalhamra.png')); ?>" alt="Ras Al Hamra" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/hyundai.png')); ?>" alt="Hyundai" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/ooredoo.png')); ?>" alt="Ooredoo" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/bankmuscat.png')); ?>" alt="Bank Muscat" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/ford.png')); ?>" alt="Ford" class="client-logo"></div>
                <!-- أضف المزيد إذا احتجت -->
            </div>
        </div>
    </div>
</div>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const isRTL = document.documentElement.dir === 'rtl';

    new Swiper('.client-logos-swiper', {
        slidesPerView: 5,
        spaceBetween: 40,
        loop: true,
        speed: 650,
        autoplay: {
            delay: 1600,
            disableOnInteraction: false,
        },
        breakpoints: {
            0:   { slidesPerView: 2, spaceBetween: 16 },
            520: { slidesPerView: 3, spaceBetween: 18 },
            768: { slidesPerView: 4, spaceBetween: 28 },
            992: { slidesPerView: 5, spaceBetween: 40 },
        },
        grabCursor: true,
        rtl: isRTL,
        allowTouchMove: true,
        // لا تحتاج arrows في هذا التصميم
    });
});
</script>

<style>
.client-logos-section {
    border-bottom: 1.2px solid #efefef;
    margin-bottom: 10px;
}
.client-logo {
    height: 50px;
    width: auto;
    max-width: 135px;
    object-fit: contain;
    filter: grayscale(100%);
    opacity: 0.86;
    transition: opacity .18s;
    display: block;
    margin: 0 auto;
    padding: 0 10px;
}
.client-logo:hover {
    opacity: 1;
    filter: grayscale(0%);
}
.swiper.client-logos-swiper {
    padding: 8px 0;
}
.swiper-slide {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 65px;
}
@media (max-width: 520px) {
    .client-logo { height: 38px; }
    .swiper-slide { height: 48px; }
}
</style>





<section class="aboutus-desc py-2">
    <div class="container">
        <div class="aboutus-mission text-center mb-4" style="color:#47494e;font-size:1.09rem;">
            <?php echo __('main.aboutus_mission'); ?>

        </div>

        <!-- Tabs (أقسام الشركات التابعة أو المشاريع) -->
        <div class="mb-4 d-flex justify-content-center flex-wrap gap-2">
            <a href="#" class="aboutus-tab"><?php echo e(__('main.aboutus_tab1')); ?></a>
            <a href="#" class="aboutus-tab"><?php echo e(__('main.aboutus_tab2')); ?></a>
            <a href="#" class="aboutus-tab"><?php echo e(__('main.aboutus_tab3')); ?></a>
        </div>

        <!-- كيس ستادي مصغر -->
        <div class="row g-4 align-items-center justify-content-center">
            <div class="col-md-5">
                <div class="aboutus-casebox p-4">
                    <div class="aboutus-case-logo mb-2">
                        <img src="<?php echo e(asset('images/seraj_logo.png')); ?>" alt="Seraj" height="30">
                    </div>
                    <div class="aboutus-case-title fw-bold mb-2" style="color:#15182b;"><?php echo e(__('main.case_title')); ?></div>
                    <div class="aboutus-case-desc mb-3 small" style="color:#5f616d;">
                        <?php echo e(__('main.case_desc')); ?>

                    </div>
                    <a href="#" class="btn btn-primary aboutus-case-btn"><?php echo e(__('main.case_btn')); ?></a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row g-2">
                    <div class="col-6"><div class="aboutus-case-img"></div></div>
                    <div class="col-6"><div class="aboutus-case-img"></div></div>
                    <div class="col-6"><div class="aboutus-case-img"></div></div>
                    <div class="col-6">
                        <div class="aboutus-case-img case-img-more">
                            <span>+4<br>Projects</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.aboutus-hero { min-height:320px; height:320px; position:relative; }
.aboutus-bg-img {
    position: absolute; top: 0; left: 0; width: 100%; height: 100%;
    object-fit: cover; z-index: 1; }
.aboutus-overlay {
    position: absolute; inset: 0; background: rgba(33,39,78,0.51);
    z-index: 2;
}
.aboutus-hero-content {
    position: relative; z-index: 3; min-height: 300px;
    justify-content: center;
}
.aboutus-title {
    color: #fff;
    font-size: 2.1rem;
    font-weight: bold;
    letter-spacing: -0.2px;
}
.aboutus-lead {
    color: #e6e7ea;
    font-size: 1.1rem;
    font-weight: 400;
    margin-top: 6px;
}
.aboutus-brands .brand-logo {
    max-width: 100px;
    max-height: 38px;
    filter: grayscale(1) brightness(0.6);
    opacity: 0.92;
    margin: 0 14px;
}
.aboutus-tab {
    display: inline-block;
    background: #f4f5fa;
    color: #223257;
    font-weight: 600;
    padding: 7px 23px;
    font-size: 1.01rem;
    border-radius: 8px;
    text-decoration: none;
    transition: background 0.15s;
    box-shadow: 0 2px 9px #22325709;
}
.aboutus-tab:hover, .aboutus-tab.active {
    background: #223257;
    color: #fff;
}
.aboutus-casebox {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 6px 26px #22325713;
}
.aboutus-case-btn {
    background: #223257;
    border-radius: 9px;
    border: none;
    font-size: 1rem;
    font-weight: 500;
    padding: 7px 25px;
}
.aboutus-case-img {
    width: 100%;
    aspect-ratio: 1.6/1;
    border-radius: 12px;
    background: #f4f5fa;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.22rem; color: #223257; font-weight: bold;
    position: relative;
}
.case-img-more {
    background: #223257;
    color: #fff;
    font-size: 1.12rem;
    display: flex; align-items: center; justify-content: center;
}
.case-img-more span { text-align: center; line-height: 1.3;}
@media (max-width: 991px) {
    .aboutus-hero { min-height:220px; height: 220px;}
    .aboutus-title { font-size: 1.23rem;}
    .aboutus-lead { font-size: 1rem;}
    .aboutus-brands .brand-logo { max-width: 80px; }
    .aboutus-casebox { padding: 16px;}
}
</style>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/temp/temp_preview_FetUmi2hlq.blade.php ENDPATH**/ ?>