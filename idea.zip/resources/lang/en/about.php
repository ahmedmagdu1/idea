<?php

return [
    // Hero
    'hero_title' => 'About IDEA Group',
    'hero_subtitle' => 'Idea Group is an ecosystem of creativity, engineering, and communication that unites three specialist companies under one vision.',

    // Mission
    'aboutus_title' => 'About IDEA Group',
    'aboutus_lead' => 'Idea Group is an ecosystem of creativity, engineering, and communication that unites three specialist companies under one vision.',
    'mission_paragraph_1' => 'Our mission is to craft ideas that leave a mark in the city, across digital spaces, and in people\'s minds.',
    'mission_paragraph_2' => 'We build holistic solutions that merge outdoor advertising, marketing, video production, spatial design, and innovation.',

    // CTA and stats
    'company_cta' => 'Explore More',
    'stats_regions_number' => '+4',
    'stats_regions_label' => 'Operating<br>Regions',

    // Visual alt text
    'visual_top_alt' => 'Creative team reviewing brand identity concepts',
    'visual_middle_alt' => 'IDEA Group studio workspace overview',
    'visual_bottom_alt' => 'Outdoor advertising installation by IDEA Group',

    // Clients carousel
    'client_chery_alt' => 'Chery',
    'client_lexus_alt' => 'Lexus',
    'client_rasalhamra_alt' => 'Ras Al Hamra',
    'client_hyundai_alt' => 'Hyundai',
    'client_ooredoo_alt' => 'Ooredoo',
    'client_bankmuscat_alt' => 'Bank Muscat',
    'client_ford_alt' => 'Ford',

    // Seraj Media
    'company_seraj_kicker' => 'IDEA GROUP',
    'company_seraj_title' => 'Seraj Media',
    'company_seraj_sub' => 'by Oneic Media',
    'company_seraj_case_title' => 'Outdoor Advertising, Video Production, 3D Content',
    'company_seraj_description' => 'A media company that works with the urban environment. We turn the city into a platform for brand communication through:',
    'company_seraj_feature_1' => 'High-impact outdoor advertising (billboards, digital screens, unconventional formats)',
    'company_seraj_feature_2' => 'Video content for digital displays',
    'company_seraj_feature_3' => 'Cutting-edge 3D animations that stop people in their tracks',
    'company_seraj_tagline' => 'Here advertising becomes art, and technology is its canvas.',
    'company_seraj_btn' => 'Explore More',

    // Ides Design
    'company_ides_kicker' => 'IDEA GROUP',
    'company_ides_title' => 'Ides Design',
    'company_ides_sub' => 'by Oneic Media',
    'company_ides_case_title' => 'Creative Design & Brand Identity',
    'company_ides_description' => 'A creative studio specializing in visual identity and brand experiences. We craft memorable designs that:',
    'company_ides_feature_1' => 'Define brand identity and logo systems',
    'company_ides_feature_2' => 'Deliver digital and print design solutions',
    'company_ides_feature_3' => 'Shape user experience and interface design',
    'company_ides_tagline' => 'Where creativity meets strategic thinking.',
    'company_ides_btn' => 'Explore More',

    // Anmat
    'company_anmat_kicker' => 'IDEA GROUP',
    'company_anmat_title' => 'Anmat',
    'company_anmat_sub' => 'by Oneic Media',
    'company_anmat_case_title' => 'Digital Solutions & Technology',
    'company_anmat_description' => 'A technology company focused on innovative digital solutions. We develop cutting-edge applications that:',
    'company_anmat_feature_1' => 'Build custom web and mobile applications',
    'company_anmat_feature_2' => 'Launch e-commerce and digital platforms',
    'company_anmat_feature_3' => 'Provide advanced analytics and automation tools',
    'company_anmat_tagline' => 'Transforming ideas into digital reality.',
    'company_anmat_btn' => 'Explore More',
];
