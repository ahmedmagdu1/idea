<?php

return [
    'title' => 'Privacy Policy',
    'last_updated' => 'Last updated',
    'content' => "This privacy policy explains how IDEA Group collects, uses, and protects your personal information when you visit our website, submit forms, or engage with our services.\n\nYou can expand this section with your specific data handling practices directly from the CMS or by editing this translation file.",
    'contact' => 'If you have any questions about this policy, contact us at privacy@ideagroup.om.',
];
