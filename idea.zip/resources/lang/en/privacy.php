<?php

return [
    'title' => 'Privacy Policy',
    'last_updated' => 'Last updated',
    'content' => 'You can manage this content later via the CMS or by editing this file.',
];
