<?php
return [
    'title' => 'Terms & Conditions',
    'last_updated' => 'Last updated',
    'content' => "These terms and conditions outline the rules and guidelines for using IDEA Group's website and services.\n\nReplace this placeholder copy with your legal content from the CMS or by editing this translation file.",
    'contact' => 'For legal questions contact legal@ideagroup.om.',
];
