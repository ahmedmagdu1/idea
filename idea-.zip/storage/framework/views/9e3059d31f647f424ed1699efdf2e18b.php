<?php $__env->startSection('title', __('admin.home')); ?>
<?php $__env->startSection('page-title', __('admin.home')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- إحصائيات -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card stats-card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-white-50 mb-1"><?php echo e(__('admin.users')); ?></h6>
                        <h3 class="mb-0">1,234</h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-users fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card stats-card success">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-white-50 mb-1"><?php echo e(__('admin.requests')); ?></h6>
                        <h3 class="mb-0">856</h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-shopping-cart fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card stats-card warning">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-white-50 mb-1"><?php echo e(__('admin.sales')); ?></h6>
                        <h3 class="mb-0">$24,500</h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-dollar-sign fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card stats-card info">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-white-50 mb-1"><?php echo e(__('admin.visits')); ?></h6>
                        <h3 class="mb-0">12,456</h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-eye fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><?php echo e(__('admin.recent_activities')); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><?php echo e(__('admin.user')); ?></th>
                                <th><?php echo e(__('admin.activity')); ?></th>
                                <th><?php echo e(__('admin.date')); ?></th>
                                <th><?php echo e(__('admin.status')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>أحمد محمد</td>
                                <td>تسجيل دخول جديد</td>
                                <td>منذ 5 دقائق</td>
                                <td><span class="badge bg-success"><?php echo e(__('admin.active')); ?></span></td>
                            </tr>
                            <tr>
                                <td>فاطمة علي</td>
                                <td>إضافة طلب جديد</td>
                                <td>منذ 15 دقيقة</td>
                                <td><span class="badge bg-primary"><?php echo e(__('admin.completed')); ?></span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><?php echo e(__('admin.quick_notifications')); ?></h5>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <?php echo e(__('admin.new_requests_pending')); ?>

                </div>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?php echo e(__('admin.backup_reminder')); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4 mb-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e(__('admin.quick_links')); ?></h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('admin.content.index')); ?>" class="btn btn-outline-primary">
                        <i class="fas fa-pen ms-1"></i> <?php echo e(__('admin.manage_content')); ?>

                    </a>
                    <a href="<?php echo e(route('admin.team.index')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-users-gear ms-1"></i> <?php echo e(__('admin.team')); ?>

                    </a>
                    <a href="<?php echo e(route('admin.press.index')); ?>" class="btn btn-outline-success">
                        <i class="fas fa-newspaper ms-1"></i> <?php echo e(__('admin.manage_press_blog')); ?>

                    </a>
                    <a href="<?php echo e(route('admin.press.create')); ?>" class="btn btn-outline-success">
                        <i class="fas fa-plus ms-1"></i> <?php echo e(__('admin.new_press_post')); ?>

                    </a>
                    <a href="<?php echo e(route('admin.careers.index')); ?>" class="btn btn-outline-info">
                        <i class="fas fa-briefcase ms-1"></i> <?php echo e(__('admin.manage_careers')); ?>

                    </a>
                    <a href="<?php echo e(route('admin.careers.create')); ?>" class="btn btn-outline-info">
                        <i class="fas fa-plus ms-1"></i> <?php echo e(__('admin.new_career')); ?>

                    </a>
                    <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-outline-dark">
                        <i class="fas fa-users ms-1"></i> <?php echo e(__('admin.users')); ?>

                    </a>
                    <a href="<?php echo e(route('admin.settings')); ?>" class="btn btn-outline-info">
                        <i class="fas fa-cog ms-1"></i> <?php echo e(__('admin.settings')); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-8 mb-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e(__('admin.recent_activity')); ?></h5>
                <span class="text-muted small"><?php echo e(__('admin.experimental')); ?></span>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?php echo e(__('admin.content_update')); ?>

                        <span class="badge bg-light text-dark"><?php echo e(__('admin.minutes_ago', ['count' => 5])); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?php echo e(__('admin.team_member_added')); ?>

                        <span class="badge bg-light text-dark"><?php echo e(__('admin.minutes_ago', ['count' => 30])); ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>