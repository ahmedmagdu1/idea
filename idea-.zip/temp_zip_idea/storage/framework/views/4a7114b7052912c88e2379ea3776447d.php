

<?php $__env->startSection('title', 'إدارة المحتوى'); ?>
<?php $__env->startSection('page-title', 'نظام إدارة المحتوى الشامل'); ?>

<?php $__env->startSection('content'); ?>
<!-- الإحصائيات الرئيسية -->
<div class="row mb-4">
    <div class="col-xl-3 col-sm-6 mb-3">
        <div class="card bg-primary text-white border-0 shadow">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="h4 fw-bold mb-0"><?php echo e($stats['total_pages']); ?></div>
                        <div class="small">إجمالي الصفحات</div>
                    </div>
                    <div class="opacity-75">
                        <i class="fas fa-file-alt fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-sm-6 mb-3">
        <div class="card bg-success text-white border-0 shadow">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="h4 fw-bold mb-0"><?php echo e($stats['total_texts']); ?></div>
                        <div class="small">إجمالي النصوص</div>
                    </div>
                    <div class="opacity-75">
                        <i class="fas fa-font fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-sm-6 mb-3">
        <div class="card bg-warning text-white border-0 shadow">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="h4 fw-bold mb-0"><?php echo e($stats['total_images']); ?></div>
                        <div class="small">إجمالي الصور</div>
                    </div>
                    <div class="opacity-75">
                        <i class="fas fa-images fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-sm-6 mb-3">
        <div class="card bg-info text-white border-0 shadow">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="h4 fw-bold mb-0"><?php echo e($stats['completion_rate']); ?>%</div>
                        <div class="small">معدل الإكمال</div>
                    </div>
                    <div class="opacity-75">
                        <i class="fas fa-chart-line fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- أدوات سريعة -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-gradient-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-tools me-2"></i>
                        أدوات سريعة
                    </h5>
                    <div class="btn-group">
                        <button type="button" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#bulkActionsModal">
                            <i class="fas fa-tasks me-2"></i>
                            عمليات مجمعة
                        </button>
                        <form method="POST" action="<?php echo e(route('admin.content.scan-all')); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-light btn-sm">
                                <i class="fas fa-search-plus me-2"></i>
                                فحص جميع الصفحات
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- شريط التقدم العام -->
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted">إجمالي التقدم</span>
                        <span class="fw-bold"><?php echo e($stats['completion_rate']); ?>%</span>
                    </div>
                    <div class="progress" style="height: 8px;">
                        <div class="progress-bar bg-gradient-success" 
                             style="width: <?php echo e($stats['completion_rate']); ?>%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- صفحات الموقع -->
<div class="row">
    <?php
        $pageIcons = [
            'welcome' => 'fa-home',
            'about' => 'fa-info-circle', 
            'services' => 'fa-cogs',
            'contact' => 'fa-envelope'
        ];
        $pageNames = [
            'welcome' => 'الصفحة الرئيسية',
            'about' => 'من نحن',
            'services' => 'خدماتنا',
            'contact' => 'اتصل بنا'
        ];
        $statusColors = [
            'complete' => 'success',
            'incomplete' => 'warning',
            'empty' => 'danger'
        ];
        $statusText = [
            'complete' => 'مكتملة',
            'incomplete' => 'ناقصة',
            'empty' => 'فارغة'
        ];
    ?>

    <?php $__currentLoopData = $pagesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
            <div class="card border-0 shadow-sm hover-card h-100">
                <div class="card-header bg-light border-0">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fas <?php echo e($pageIcons[$page] ?? 'fa-file'); ?> fa-lg text-primary me-2"></i>
                            <h6 class="mb-0 fw-bold"><?php echo e($pageNames[$page] ?? ucfirst($page)); ?></h6>
                        </div>
                        <span class="badge bg-<?php echo e($statusColors[$data['status']]); ?>">
                            <?php echo e($statusText[$data['status']]); ?>

                        </span>
                    </div>
                </div>
                
                <div class="card-body">
                    <!-- إحصائيات الصفحة -->
                    <div class="row text-center mb-3">
                        <div class="col-4">
                            <div class="border-end">
                                <div class="h5 text-info mb-1"><?php echo e($data['text_count']); ?></div>
                                <small class="text-muted">نص</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="border-end">
                                <div class="h5 text-warning mb-1"><?php echo e($data['image_count']); ?></div>
                                <small class="text-muted">صورة</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="h5 text-success mb-1">
                                <?php echo e($data['status'] === 'complete' ? '100' : ($data['status'] === 'incomplete' ? '50' : '0')); ?>%
                            </div>
                            <small class="text-muted">مكتمل</small>
                        </div>
                    </div>
                    
                    <!-- آخر تعديل -->
                    <div class="mb-3">
                        <small class="text-muted d-block">
                            <i class="fas fa-clock me-1"></i>
                            آخر تعديل: <?php echo e($data['last_modified']); ?>

                        </small>
                    </div>
                    
                    <!-- الأزرار -->
                    <div class="d-grid gap-2">
                        <a href="<?php echo e(route('admin.content.show', $page)); ?>" 
                           class="btn btn-primary">
                            <i class="fas fa-edit me-2"></i>
                            تحرير المحتوى
                        </a>
                        
                        <div class="btn-group">
                            <a href="<?php echo e(route('admin.content.preview', $page)); ?>" 
                               class="btn btn-outline-info btn-sm" target="_blank">
                                <i class="fas fa-eye me-1"></i>
                                معاينة
                            </a>
                            <form method="POST" action="<?php echo e(route('admin.content.scan-page', $page)); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-success btn-sm">
                                    <i class="fas fa-sync-alt me-1"></i>
                                    فحص
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- نشاط حديث -->
<div class="row mt-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2"></i>
                    النشاط الحديث
                </h5>
            </div>
            <div class="card-body">
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-marker bg-success"></div>
                        <div class="timeline-content">
                            <h6 class="mb-1">تم تحديث صفحة الخدمات</h6>
                            <p class="mb-1 text-muted">تم إضافة 5 نصوص جديدة و 3 صور</p>
                            <small class="text-muted">منذ ساعتين</small>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-marker bg-info"></div>
                        <div class="timeline-content">
                            <h6 class="mb-1">فحص تلقائي للصفحات</h6>
                            <p class="mb-1 text-muted">تم اكتشاف 12 عنصر جديد</p>
                            <small class="text-muted">منذ 4 ساعات</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal للعمليات المجمعة -->
<div class="modal fade" id="bulkActionsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">العمليات المجمعة</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?php echo e(route('admin.content.bulk-actions')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">نوع العملية</label>
                        <select name="action" class="form-select" required>
                            <option value="">اختر العملية</option>
                            <option value="backup">إنشاء نسخة احتياطية</option>
                            <option value="export">تصدير المحتوى</option>
                            <option value="import">استيراد المحتوى</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">الصفحات المحددة</label>
                        <div class="form-check-group">
                            <?php $__currentLoopData = $pagesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="pages[]" value="<?php echo e($page); ?>" id="page_<?php echo e($page); ?>">
                                    <label class="form-check-label" for="page_<?php echo e($page); ?>">
                                        <?php echo e($pageNames[$page] ?? $page); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-primary">تنفيذ</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<style>
.hover-card {
    transition: transform 0.2s ease-in-out;
}
.hover-card:hover {
    transform: translateY(-5px);
}
.bg-gradient-primary {
    background: linear-gradient(45deg, #007bff, #0056b3);
}
.bg-gradient-success {
    background: linear-gradient(45deg, #28a745, #1e7e34);
}
.timeline {
    position: relative;
    padding-left: 30px;
}
.timeline::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #dee2e6;
}
.timeline-item {
    position: relative;
    margin-bottom: 20px;
}
.timeline-marker {
    position: absolute;
    left: -23px;
    top: 5px;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    border: 3px solid #fff;
    box-shadow: 0 0 0 3px #dee2e6;
}
.timeline-content {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    border-left: 3px solid #007bff;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/admin/simple-content/index.blade.php ENDPATH**/ ?>