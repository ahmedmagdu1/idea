<?php

return [
    'welcome' => 'Welcome to our website!',
    'login' => 'Login',
    'logout' => 'Logout',
];
