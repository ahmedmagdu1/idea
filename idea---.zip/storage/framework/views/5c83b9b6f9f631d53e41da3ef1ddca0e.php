<?php $__env->startSection('title', 'Careers'); ?>

<?php $__env->startSection('content'); ?>

<style>
    * {
/* Hero text exact mapping (Figma) */
.aboutus-hero .aboutus-title {
  color: #fff;
  font-family: 'Poppins', sans-serif;
  font-weight: 600;
  font-style: normal;
  font-size: 57.96px;
  line-height: 1.33;
  letter-spacing: 0;
  vertical-align: middle;
}
.aboutus-hero .aboutus-lead {
  color: #fff;
  font-family: 'Poppins', sans-serif;
  font-weight: 400;
  font-style: normal;
  font-size: 26.39px;
  line-height: 1.0;
  letter-spacing: 0;
  text-align: center;
}

/* Hero Section */
.hero-section {
  position: relative;
  height: 620px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.hero-bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  z-index: 1;
}

.hero-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: #161c2d;
  opacity: 0.7;
  z-index: 2;
}

.hero-content {
  position: relative;
  z-index: 3;
  text-align: center;
  color: white;
  padding: 0 2rem;
  animation: fadeInUp 1s ease;
}

.hero-title {
  font-size: 3.625rem;
  font-weight: 600;
  margin-bottom: 1.5rem;
  animation: fadeInUp 1s ease 0.2s backwards;
}

.hero-description {
  font-size: 1.65rem;
  max-width: 894px;
  margin: 0 auto;
  line-height: 1.6;
  animation: fadeInUp 1s ease 0.4s backwards;
}
</style>

    <!-- Hero Section -->
  <section class="hero-section">
    <div class="hero-overlay"></div>
    <img src="https://images.unsplash.com/photo-1484980859177-5ac1249fda6f?q=80&w=1600&auto=format&fit=crop" alt="Background" class="hero-bg">
    <div class="hero-content">
      <h1 class="hero-title text-light">Careers</h1>
      <p class="hero-description text-light">
     Join our team to build standout experiences.
     </p>
    </div>
  </section>





<div class="container py-5">
  <div class="row g-4">
    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title mb-1"><a href="<?php echo e(url('/careers/'.$item->slug)); ?>"><?php echo e($item->title); ?></a></h5>
            <div class="text-muted small mb-2"><?php echo e($item->location); ?> <?php if($item->type): ?> • <?php echo e($item->type); ?> <?php endif; ?></div>
            <p class="card-text flex-grow-1"><?php echo e(Str::limit($item->excerpt ?: strip_tags($item->body), 120)); ?></p>
            <a class="btn btn-brand mt-2" href="<?php echo e(url('/careers/'.$item->slug)); ?>">View role</a>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="col-12 text-center text-muted">No open positions at the moment.</div>
    <?php endif; ?>
  </div>
  <div class="mt-4"><?php echo e($items->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/careers/index.blade.php ENDPATH**/ ?>