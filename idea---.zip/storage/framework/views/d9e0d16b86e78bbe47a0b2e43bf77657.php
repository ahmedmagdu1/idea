﻿

<?php $__env->startSection('title', __('messages.welcome')); ?>

<?php $__env->startSection('content'); ?>
<style>
    * {
/* Hero text exact mapping (Figma) */
.aboutus-hero .aboutus-title {
  color: #fff;
  font-family: 'Poppins', sans-serif;
  font-weight: 600;
  font-style: normal;
  font-size: 57.96px;
  line-height: 1.33;
  letter-spacing: 0;
  vertical-align: middle;
}
.aboutus-hero .aboutus-lead {
  color: #fff;
  font-family: 'Poppins', sans-serif;
  font-weight: 400;
  font-style: normal;
  font-size: 26.39px;
  line-height: 1.0;
  letter-spacing: 0;
  text-align: center;
}

  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Poppins', sans-serif;
  color: #131313;
  overflow-x: hidden;
}

/* Navigation */
.navbar {
  padding: 1.5rem 0;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  z-index: 1000;
}

.navbar-brand {
  font-size: 2rem;
  color: #000;
  letter-spacing: -0.19px;
}

.nav-link {
  font-size: 1.5rem;
  color: #000;
  padding: 0.5rem 1rem;
  transition: color 0.3s ease;
}

.nav-link:hover,
.nav-link.active {
  color: #2c385a;
}

/* Hero Section */
.hero-section {
  position: relative;
  height: 620px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.hero-bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  z-index: 1;
}

.hero-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: #161c2d;
  opacity: 0.7;
  z-index: 2;
}

.hero-content {
  position: relative;
  z-index: 3;
  text-align: center;
  color: white;
  padding: 0 2rem;
  animation: fadeInUp 1s ease;
}

.hero-title {
  font-size: 3.625rem;
  font-weight: 600;
  margin-bottom: 1.5rem;
  animation: fadeInUp 1s ease 0.2s backwards;
}

.hero-description {
  font-size: 1.65rem;
  max-width: 894px;
  margin: 0 auto;
  line-height: 1.6;
  animation: fadeInUp 1s ease 0.4s backwards;
}

/* Service Sections */
.service-section {
  animation: fadeInUp 1s ease;
}

.service-card {
  background: #f4f7fa;
  border-radius: 15px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.service-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
}

.service-card-dark {
  background: #2c385a;
}

/* Make service-content white inside dark cards */
.service-card-dark .service-content,
.service-card-dark .service-content p,
.service-card-dark .service-content li,
.service-card-dark .service-content a {
  color: #fff;
}
.service-card-dark .service-content a:hover { color: #e4e8f5; }
/* Ensure subtitle also turns white on dark cards */
.service-card-dark .service-subtitle { color:#fff; }

.service-subtitle {
  font-size: 1.375rem;
  color: #3b496f;
  font-weight: 500;
  margin-bottom: 1rem;
}

.service-title {
  font-size: 4.25rem;
  font-weight: 700;
  color: #3b496f;
  margin-bottom: 2rem;
  line-height: 1.2;
}

.service-card-dark .service-title {
  color: white;
}

.service-content {
  font-family: 'Poppins', sans-serif;
  font-weight: 400;
  font-style: normal;
  font-size: 26px;
  line-height: 1.6;
  margin-bottom: 3rem;
}

.service-content p {
  margin-bottom: 1.5rem;
}

.service-content ul {
  padding-left: 1.5rem;
}

.service-content ul li {
  margin-bottom: 0.5rem;
}

.service-image {
  background: #d9d9d9;
  height: 100%;
  min-height: 400px;
}

/* Buttons */
.btn-custom {
  background: #2c385a;
  color: white;
  padding: 1.125rem 1.875rem;
  font-size: 1.125rem;
  font-weight: 600;
  letter-spacing: 1.8px;
  border-radius: 10px;
  border: none;
  box-shadow: 0 1.85px 3.15px rgba(68, 68, 68, 0.024),
              0 8.15px 6.52px rgba(68, 68, 68, 0.04),
              0 20px 13px rgba(68, 68, 68, 0.05),
              0 38.52px 25.48px rgba(68, 68, 68, 0.063),
              0 64.81px 46.85px rgba(68, 68, 68, 0.075),
              0 100px 80px rgba(68, 68, 68, 0.102);
  transition: all 0.3s ease;
}

.btn-custom:hover {
  background: #3d4a6e;
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(44, 56, 90, 0.3);
}

.btn-custom-light {
  background: white;
  color: #2c385a;
  padding: 1.125rem 1.875rem;
  font-size: 1.125rem;
  font-weight: 600;
  letter-spacing: 1.8px;
  border-radius: 10px;
  border: 2px solid white;
  transition: all 0.3s ease;
}

.btn-custom-light:hover {
  background: #f5f5f5;
  color: #2c385a;
  transform: translateY(-2px);
}

/* CTA Section */
.cta-section {
  position: relative;
  height: 576px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  margin-top: 5rem;
}

.cta-bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  z-index: 1;
}

.cta-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: #2c385a;
  opacity: 0.85;
  z-index: 2;
}

.cta-content {
  position: relative;
  z-index: 3;
  text-align: center;
  color: white;
  padding: 0 2rem;
}

.cta-title {
  font-size: 3.125rem;
  font-weight: 500;
  margin-bottom: 2rem;
  line-height: 1.27;
  letter-spacing: -1.59px;
}

.cta-description {
  font-size: 1.375rem;
  font-weight: 500;
  margin-bottom: 3rem;
  line-height: 1.52;
}

.btn-cta {
  background: white;
  color: #161c2d;
  padding: 0.75rem 3rem;
  font-size: 1.0625rem;
  font-weight: 700;
  border-radius: 8px;
  border: none;
  letter-spacing: -0.5px;
  transition: all 0.3s ease;
}

.btn-cta:hover {
  background: #f5f5f5;
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(255, 255, 255, 0.3);
}

/* Footer */
.footer {
  padding: 2rem 0;
  margin-top: 5rem;
}

.footer-line {
  border-top: 1px solid #ddd;
  margin: 0;
}

.footer p {
  font-size: 1.0125rem;
  color: #161c2d;
  letter-spacing: -0.11px;
}

/* Animations */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Responsive Design */
@media (max-width: 991.98px) {
  .hero-title {
    font-size: 2.5rem;
  }

  .hero-description {
    font-size: 1.25rem;
  }

  .service-title {
    font-size: 2.5rem;
  }

  .service-content {
    font-size: 1.25rem;
  }

  .service-image {
    min-height: 300px;
  }

  .cta-title {
    font-size: 2rem;
  }

  .cta-description {
    font-size: 1.125rem;
  }

  .navbar-brand {
    font-size: 1.5rem;
  }

  .nav-link {
    font-size: 1.125rem;
  }
}

@media (max-width: 767.98px) {
  .hero-section {
    height: 500px;
  }

  .hero-title {
    font-size: 2rem;
  }

  .hero-description {
    font-size: 1rem;
  }

  .service-title {
    font-size: 2rem;
  }

  .service-content {
    font-size: 1rem;
  }

  .btn-custom,
  .btn-custom-light {
    font-size: 0.875rem;
    padding: 0.875rem 1.5rem;
  }

  .cta-section {
    height: 400px;
  }

  .cta-title {
    font-size: 1.5rem;
  }

  .cta-description {
    font-size: 1rem;
  }
}
</style>
  <!-- Hero Section -->
  <section class="hero-section">
    <div class="hero-overlay"></div>
    <img src="https://c.animaapp.com/mh4m526aXDXfcg/img/bg.png" alt="Background" class="hero-bg">
    <div class="hero-content">
      <h1 class="hero-title text-light">Services</h1>
      <p class="hero-description text-light">
        Idea Group is an ecosystem of creativity, engineering, and communication — uniting three expert companies under one vision.
      </p>
    </div>
  </section>

  <!-- Main Content -->
  <main class="container-fluid px-5 py-5">

    <!-- OOH Marketing Section -->
    <section class="service-section mb-5">
      <div class="service-card">
        <div class="row g-0">
          <div class="col-lg-7 p-5">
            <p class="service-subtitle">(Out-of-Home)</p>
            <h2 class="service-title">OOH Marketing</h2>
            <div class="service-content">
              <p>At Idea Group, we offer the largest OOH coverage across Oman, with a growing network of over 300+ static and digital billboards.</p>
              <p>Our premium digital screens are strategically located in key areas such as Azaiba, Amerat, Khuwair, Ruwi, Nizwa, Mabeelah, and Qurum — ensuring maximum visibility for your brand.</p>
              <p>We also provide digital screens for exhibitions and major events, offering dynamic advertising opportunities. Our team can design both static banners and engaging video content, delivering powerful, high-impact campaigns tailored to your goals.</p>
              <p>We don't just promote — we build connections.</p>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom" href="/company-profile"><?php echo e(__("services.company_profile")); ?></a>
              <a class="btn btn-custom" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/services/events.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
        </div>
      </div>
    </section>

    <!-- Interior & Exterior Design Section -->
    <section class="service-section mb-5">
      <div class="service-card service-card-dark">
        <div class="row g-0">
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/services/interior.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
          <div class="col-lg-7 p-5">
            <h2 class="service-title text-white">Interior & Exterior Design</h2>
            <div class="service-content text-white">
              <p>At Idea Group, we create spaces that work for your business. We specialize in the design of interiors and exteriors for residential complexes, business centers, retail spaces, recreational areas, restaurants, shops, and offices.</p>
              <p>Our team crafts solutions that reflect your brand's philosophy, enhance customer impressions, and maximize functionality. From concept development and 3D visualization to full project supervision — we deliver spaces that inspire and help businesses grow.</p>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom-light" href="/company-profile"><?php echo e(__("services.company_profile")); ?></a>
              <a class="btn btn-custom-light" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
            </div>
          </div>
        </div>
      </div>
    </section>



    <!-- Branding Section -->
    <section class="service-section mb-5">
      <div class="service-card">
        <div class="row g-0">
          <div class="col-lg-7 p-5">
            <h2 class="service-title">Branding</h2>
            <div class="service-content">
              <p>At Idea Group, we build brands that tell stories and resonate with people.</p>
              <p>Our approach combines the authenticity of Omani style with contemporary global trends, preserving cultural identity while ensuring modern relevance.</p>
              <p>We develop logos, visual systems, packaging, brand guidelines, and comprehensive brand strategies that help companies stand out, stay true to their roots, and succeed in a competitive market.</p>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom" href="/company-profile"><?php echo e(__("services.company_profile")); ?></a>
              <a class="btn btn-custom" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/branding.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
        </div>
      </div>
    </section>


        <!-- Digital Marketing Section -->
    <section class="service-section mb-5">
      <div class="service-card service-card-dark">
        <div class="row g-0">
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/services/digital-marketing.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
          <div class="col-lg-7 p-5">
            <h2 class="service-title text-white">Digital Marketing</h2>
            <div class="service-content text-white">
              <p>At <strong>Idea Group</strong>, through our agency <strong>Ideas Design</strong>, we offer full-cycle digital marketing services tailored to your business goals. From strategic planning to execution, we cover the entire customer journey—creating websites, landing pages, and e-commerce platforms that reflect your brand and drive results.</p>
              <p>We craft creative, data-driven campaigns across social media, Google Ads, and email marketing to attract, engage, and convert your audience. Our focus is on building meaningful digital experiences that boost brand visibility, loyalty, and growth.</p>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom-light" href="/company-profile"><?php echo e(__("services.company_profile")); ?></a>
              <a class="btn btn-custom-light" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!-- Video Production Section -->
    <section class="service-section mb-5">
      <div class="service-card">
        <div class="row g-0">
          <div class="col-lg-7 p-5">
            <h2 class="service-title">Video Production</h2>
            <div class="service-content">
              <p>Video that doesn't just tell a story — it captivates.</p>
              <p>We create visual content that evokes emotion, enhances your brand identity, and delivers results. From concept to final edit, we craft every element: script, style, music, effects, and overall narrative.</p>
              <p class="fw-bold">Our services include:</p>
              <p>
                Promo and advertising videos<br>
                Social media and YouTube content<br>
                AI-generated creative videos<br>
                Real estate, brand, and product presentations<br>
                Editing, animation, voiceovers, and subtitles
              </p>
              <p>Show who you are — not just in words, but through powerful visuals.</p>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom" href="/catalogue.pdf" download><?php echo e(__("services.download_catalogue")); ?></a>
              <a class="btn btn-custom" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
              <a class="btn btn-custom" href="/services"><?php echo e(__("services.explore_more")); ?></a>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/services/video.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
        </div>
      </div>
    </section>

    <!-- Business Gifts Section -->
    <section class="service-section mb-5">
      <div class="service-card service-card-dark">
        <div class="row g-0">
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/services/gifts.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
          <div class="col-lg-7 p-5">
            <h2 class="service-title text-white">Business Gifts and Trophies</h2>
            <div class="service-content text-white">
              <p>Special moments deserve special recognition.</p>
              <p>At Idea Group, we design and produce custom business gifts, awards, and trophies that reflect the prestige of your brand and honor every achievement.</p>
              <p>Our trophies have already gained popularity among leading companies in Oman and have been proudly presented to distinguished figures, including members of the royal family. Perfect for corporate events, employee recognition programs, and client appreciation programs — our creations are not just awards, but symbols of excellence and success.</p>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom-light" href="/services"><?php echo e(__("services.learn_more")); ?></a>
              <a class="btn btn-custom-light" href="/portfolio"><?php echo e(__("services.gallery")); ?></a>
              <a class="btn btn-custom-light" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Event Organization Section -->
    <section class="service-section mb-5">
      <div class="service-card">
        <div class="row g-0">
          <div class="col-lg-7 p-5">
            <h2 class="service-title">Event Organization</h2>
            <div class="service-content">
              <p>We bring your brand to life through unforgettable business events.</p>
              <p>At Idea Group, we specialize in organizing exhibitions, conferences, and corporate business events that strengthen your brand's position and reputation.</p>
              <p>Our team handles every stage — from concept development and strategic planning to logistics and on-site coordination.</p>
              <p>We create professional events that leave a lasting impression and drive real business results.</p>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom" href="/company-profile"><?php echo e(__("services.company_profile")); ?></a>
              <a class="btn btn-custom" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/services/events.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
        </div>
      </div>
    </section>

    <!-- Web Development Section -->
    <section class="service-section mb-5">
      <div class="service-card service-card-dark">
        <div class="row g-0">
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/services/web.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
          <div class="col-lg-7 p-5">
            <h2 class="service-title text-white">Web Development</h2>
            <div class="service-content text-white">
              <p>A website isn't just a digital business card — it's your brand's home online. We build websites that boost your credibility, increase sales, and strengthen recognition. Visually compelling, technically solid, and strategically aligned with your goals.</p>
              <p class="fw-bold">We offer:</p>
              <ul>
                <li>Corporate websites and landing pages</li>
                <li>Sites for real estate, restaurants, shops, salons</li>
                <li>Multilingual websites</li>
                <li>Fully responsive design</li>
                <li>Ongoing support and SEO optimization</li>
                <li>Complete service: structure, design, content, and development</li>
              </ul>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom-light" href="/company-profile"><?php echo e(__("services.company_profile")); ?></a>
              <a class="btn btn-custom-light" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Permits Section -->
    <section class="service-section mb-5">
      <div class="service-card">
        <div class="row g-0">
          <div class="col-lg-7 p-5">
            <h2 class="service-title">Permits and Certifications</h2>
            <div class="service-content">
              <p>Opening a café or restaurant?</p>
              <p>Idea Group simplifies the certification process, helping you obtain all the necessary approvals to ensure your kitchen meets hygiene and safety standards.</p>
              <p>We assist in securing key certifications and permits, including ISO certifications for food safety management (ISO 22000), ensuring your business fully complies with local and international regulations.</p>
              <p>With us, you can launch and operate your food business confidently and professionally.</p>
            </div>
            <div class="d-flex gap-3 flex-wrap">
              <a class="btn btn-custom" href="/contact"><?php echo e(__("services.contact_us")); ?></a>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="service-image" style="background-image:url('<?php echo e(asset('images/services/permits.png')); ?>');background-size:cover;background-position:center;"></div>
          </div>
        </div>
      </div>
    </section>

  </main>



<?php $__env->stopSection(); ?>











<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/services.blade.php ENDPATH**/ ?>