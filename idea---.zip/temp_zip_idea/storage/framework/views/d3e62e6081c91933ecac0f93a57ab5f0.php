<?php $__env->startSection('title', __('messages.welcome')); ?>

<?php $__env->startSection('content'); ?>
<!-- Digital Slider Section (Copy this into your Blade view) -->
<section class="section-digital-slider position-relative">
    <div class="bg-img"></div>
    <div class="container-fluid px-0 digital-slider-content" style="max-width:100vw;">
        <div class="row w-100 flex-nowrap flex-lg-row flex-column-reverse">
            <!-- LEFT TEXT -->
            <div class="col-lg-5 d-flex align-items-center justify-content-center" style="min-height:350px;">
                <div class="digital-service-text ps-lg-5 ps-3 w-100">
                    <div id="sliderServiceNum" class="slider-num">01</div>
                    <div id="sliderServiceTitle" class="slider-title">OOH Marketing</div>
                    <div id="sliderServiceDesc" class="slider-desc">
                        Outdoor, billboard and offline marketing to maximize your reach.
                    </div>
                </div>
            </div>
           <!-- TABS -->
<div class="col-lg-7 d-flex align-items-center justify-content-lg-end justify-content-center">
    <div class="digital-services-tabs ms-lg-auto pt-2 me-0 w-100 pe-lg-5 d-none d-lg-block">
        <ul class="nav flex-column gap-1" id="digitalTabs">
                        <li class="nav-item">
                            <a class="nav-link active"
                               data-num="01"
                               data-title="OOH Marketing"
                               data-desc="Outdoor, billboard and offline marketing to maximize your reach."
                               href="#">
                               OOH Marketing
                               <span class="service-num">01</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               data-num="02"
                               data-title="Gifts and Trophies"
                               data-desc="Customized corporate gifts and trophies for memorable branding."
                               href="#">
                               Gifts and Trophies
                               <span class="service-num">02</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               data-num="03"
                               data-title="Digital Marketing"
                               data-desc="Comprehensive digital campaigns across all online platforms."
                               href="#">
                               Digital Marketing
                               <span class="service-num">03</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               data-num="04"
                               data-title="Interior &amp; Exterior Design"
                               data-desc="Creative interior and exterior solutions for impactful spaces."
                               href="#">
                               Interior &amp; Exterior Design
                               <span class="service-num">04</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               data-num="05"
                               data-title="Game Development"
                               data-desc="Game development services to boost your brand engagement."
                               href="#">
                               Game Development
                               <span class="service-num">05</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               data-num="06"
                               data-title="Video Production"
                               data-desc="High-quality video production for commercials and storytelling."
                               href="#">
                               Video Production
                               <span class="service-num">06</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               data-num="07"
                               data-title="Branding"
                               data-desc="Brand identity, strategy and complete brand building solutions."
                               href="#">
                               Branding
                               <span class="service-num">07</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               data-num="08"
                               data-title="Web Development"
                               data-desc="Websites and digital platforms tailored for your business."
                               href="#">
                               Web Development
                               <span class="service-num">08</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               data-num="09"
                               data-title="Event Organization"
                               data-desc="Complete event planning and organization for your business."
                               href="#">
                               Event Organization
                               <span class="service-num">09</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Arrows for mobile slider (optional) -->
        <div class="slider-arrows d-lg-none">
            <button class="slider-arrow prev" type="button"><span>&#8592;</span></button>
            <button class="slider-arrow next" type="button"><span>&#8594;</span></button>
        </div>
    </div>
</section>

<!-- Bootstrap 5 CDN (add to your layout if not included) -->
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"> -->

<style>
/* Core Section */
.section-digital-slider {
    min-height: 430px;
    height: 773px;
    background: #24385A;
    position: relative;
    color: #fff;
    overflow: hidden;
    font-family: 'Poppins', 'Tajawal', Arial, sans-serif;
    width: 100vw;
    max-width: 100vw;
    padding: 0;
}
.section-digital-slider .bg-img {
    position: absolute;
    inset: 0;
    width: 100vw;
    height: 100%;
    z-index: 1;
    background:
        linear-gradient(90deg, rgba(36,56,90,0.92) 0%, rgba(36,56,90,0.48) 35%, rgba(36,56,90,0.10) 78%, rgba(255,255,255,0.01) 100%),
        url('<?php echo e(asset('images/BG Copy.png')); ?>') center center/cover no-repeat;
    opacity: 1;
    pointer-events: none;
}
.digital-slider-content { position: relative; z-index: 2; min-height: 430px; }
.digital-service-text {
    min-height: 310px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    gap: 0.65rem;
    transition: all .42s cubic-bezier(.4,1,.5,1.1);
}
.slider-num {
    font-size: 3.7rem; font-weight: 800; letter-spacing: 2px; color: #fff; line-height: 1; margin-bottom: 2px;
    transition: color .29s;
}
.slider-title {
    font-size: 2.25rem; font-weight: 700; letter-spacing: 0.5px; color: #fff; margin-bottom: 2px; line-height: 1.15;
    transition: color .29s;
}
.slider-desc {
    font-size: 1.11rem; line-height: 1.55; color: #e8f2ff; max-width: 440px; font-weight: 400;
    transition: color .29s;
}
.digital-services-tabs {
    z-index: 3; width: 92%; max-width: 475px; margin-left: auto; margin-right: 0; margin-top: 0;
    background: transparent; border-radius: 18px; box-shadow: 0 4px 32px 0 rgba(20,35,62,0.11);
}
.digital-services-tabs .nav-link {
    background: rgba(24, 36, 62, 0.81); color: #fff; margin-bottom: 12px;
    border-radius: 18.34px; padding: 18px 28px 18px 28px;
    font-size: 1.18rem; font-weight: 400; display: flex;
    justify-content: space-between; align-items: center;
    transition: background .28s cubic-bezier(.4,1,.5,1.1), color .16s, transform .16s;
    border: none;
    letter-spacing: 0.01em; position: relative;
    box-shadow: 0 2px 10px 0 rgba(20,35,62,0.08);
    cursor: pointer;
    outline: none;
    overflow: hidden;
}
.digital-services-tabs .nav-link .service-num {
    font-size: 1.33rem; font-weight: bold; opacity: 0.7;
    margin-left: 24px; font-family: inherit; letter-spacing: 1px;
    transition: color .19s, opacity .19s;
}
.digital-services-tabs .nav-link.active,
.digital-services-tabs .nav-link:focus,
.digital-services-tabs .nav-link:hover {
    background: #173466;
    color: #67d5ff;
    font-weight: 700;
    transform: translateX(-10px) scale(1.03);
    box-shadow: 0 12px 32px 0 rgba(97,210,255,0.08);
    outline: none;
}
.digital-services-tabs .nav-link.active .service-num,
.digital-services-tabs .nav-link:hover .service-num {
    color: #67d5ff !important;
    opacity: 1;
}
.digital-services-tabs .nav-link.active::before,
.digital-services-tabs .nav-link:hover::before {
    content: "";
    position: absolute;
    left: -12px;
    top: 10%;
    height: 80%;
    width: 7px;
    background: linear-gradient(180deg, #67d5ff 0%, #365988 100%);
    border-radius: 9px 0 0 9px;
    box-shadow: 0 0 16px #61d2ff54;
    transition: all .25s cubic-bezier(.5,.95,.45,1.2);
    opacity: 1;
}
.digital-services-tabs .nav-link:last-child { margin-bottom: 0; }

/* Arrows for mobile slider */
.slider-arrows {
    display: flex;
    justify-content: center;
    gap: 12px;
    margin-top: 18px;
}
.slider-arrow {
    background: #22355a;
    color: #67d5ff;
    border: none;
    width: 46px; height: 46px;
    border-radius: 50%;
    font-size: 1.75rem;
    box-shadow: 0 2px 8px rgba(36,56,90,0.08);
    display: flex; align-items: center; justify-content: center;
    transition: background .18s, color .16s, box-shadow .18s;
}
.slider-arrow:active, .slider-arrow:focus, .slider-arrow:hover {
    background: #67d5ff;
    color: #22355a;
    box-shadow: 0 4px 20px #67d5ff32;
}

/* Mobile: Make tabs horizontally scrollable */
@media (max-width: 991px) {
    .section-digital-slider {
        background: #24385A;
        padding: 0;
        min-height: 420px;
        height: auto;
    }
    .section-digital-slider .bg-img {
        background:         linear-gradient(90deg, rgba(36,56,90,0.92) 0%, rgba(36,56,90,0.48) 35%, rgba(36,56,90,0.10) 78%, rgba(255,255,255,0.01) 100%),
        url('<?php echo e(asset('images/BG Copy.png')); ?>') center center/cover no-repeat;
        opacity: 1 !important;
        filter: none !important;
    }
    .digital-slider-content {
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        align-items: flex-start;
        min-height: 420px;
        padding: 0 14px 22px 14px;
        width: 100vw;
        background: none !important;
    }
    .digital-service-text {
        background: none !important;
        box-shadow: none !important;
        padding: 0;
        margin: 0 0 12px 0;
        width: 100%;
        align-items: flex-start;
        text-align: left;
    }
    .slider-num {
        font-size: 2rem;
        font-weight: 800;
        color: #fff;
        margin-bottom: 4px;
        margin-left: 0;
        letter-spacing: 1.2px;
    }
    .slider-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: #fff;
        margin-bottom: 8px;
    }
    .slider-desc {
        font-size: 0.98rem;
        line-height: 1.55;
        color: #e8f2ff;
        font-weight: 400;
        margin-bottom: 10px;
        max-width: 100%;
    }
    .slider-arrows {
        display: flex;
        gap: 14px;
        margin: 0 0 0 0;
        padding-left: 0;
    }
    .slider-arrow {
        background: none !important;
        border: none;
        color: #fff;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        font-size: 1.4rem;
        box-shadow: none;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color .16s;
        outline: none;
        padding: 0;
    }
    .slider-arrow:focus,
    .slider-arrow:hover {
        color: #67d5ff !important;
        background: none !important;
    }
}

@media (max-width: 576px) {
    .digital-service-text { padding-left: 0; }
    .section-digital-slider { min-height: 180px; }
    .slider-title { font-size: 1.35rem; }
    .slider-num { font-size: 2.1rem; }
    .slider-desc { font-size: 0.98rem; }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tabs = document.querySelectorAll('#digitalTabs .nav-link');
    const serviceNum = document.getElementById('sliderServiceNum');
    const serviceTitle = document.getElementById('sliderServiceTitle');
    const serviceDesc = document.getElementById('sliderServiceDesc');
    let activeIndex = 0;

    function activateTab(idx) {
        tabs.forEach((tab, i) => {
            tab.classList.toggle('active', i === idx);
        });
        serviceNum.innerText = tabs[idx].getAttribute('data-num');
        serviceTitle.innerText = tabs[idx].getAttribute('data-title');
        serviceDesc.innerText = tabs[idx].getAttribute('data-desc');
        activeIndex = idx;
        // Scroll tab into view on mobile
        if(window.innerWidth <= 991) {
            tabs[idx].scrollIntoView({behavior:"smooth", inline:"center", block:"nearest"});
        }
    }

    tabs.forEach((tab, idx) => {
        tab.addEventListener('mouseenter', () => activateTab(idx));
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            activateTab(idx);
        });
        // optional: touch support
        tab.addEventListener('touchstart', () => activateTab(idx), {passive:true});
    });

    // Slider arrows for mobile/tablet
    const prevBtn = document.querySelector('.slider-arrow.prev');
    const nextBtn = document.querySelector('.slider-arrow.next');
    if(prevBtn && nextBtn) {
        prevBtn.addEventListener('click', function() {
            let newIndex = (activeIndex - 1 + tabs.length) % tabs.length;
            activateTab(newIndex);
        });
        nextBtn.addEventListener('click', function() {
            let newIndex = (activeIndex + 1) % tabs.length;
            activateTab(newIndex);
        });
    }
});
</script>












<section class="about-section py-5" style="background: #fff;">
    <div class="container">
        <!-- Title & Lead -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div style="letter-spacing:1.3px; color:#4d5674; font-size:0.98rem; font-weight:600; margin-bottom:2px;">
                    <?php echo e(__('main.about_small')); ?>

                </div>
                <h1 class="fw-bold mb-3" style="color:#223257;font-size:2.6rem;letter-spacing:-1px;">
                    <?php echo e(__('main.about_title')); ?>

                </h1>
                <div class="mb-2" style="color:#223257;font-weight:600;font-size:1.13rem;">
                    <?php echo __('main.about_lead'); ?>

                </div>
                <div class="mb-3" style="color:#222; font-size:1.07rem; font-weight:400;">
                    <?php echo e(__('main.about_p1')); ?>

                </div>
                <div class="mb-2" style="color:#444; font-size:1.08rem; font-weight:400;">
                    <?php echo __('main.about_p2'); ?>

                </div>
            </div>
        </div>
        <!-- Image & We Create -->
        <div class="row align-items-center g-4">
            <div class="col-md-5">
                <img src="<?php echo e(asset('images/about.png')); ?>" alt="About Us" class="img-fluid shadow-sm" style="max-height:510px; object-fit:cover; border-radius:18px;">
            </div>
            <div class="col-md-7">
                <div class="about-create-card p-4" style="background:#fff; border-radius:19px; box-shadow:0 7px 30px #22325710;">
                    <div style="color:#223257; font-size:1.34rem; font-weight:700; margin-bottom: 14px;">
                        <?php echo e(__('main.about_create_title')); ?>

                    </div>
                    <ul style="color:#374151; font-size:1.11rem; font-weight:500; padding-left:1.5rem; margin-bottom: 0;">
                        <li><?php echo e(__('main.about_create_1')); ?></li>
                        <li><?php echo e(__('main.about_create_2')); ?></li>
                        <li><?php echo e(__('main.about_create_3')); ?></li>
                        <li><?php echo e(__('main.about_create_4')); ?></li>
                        <li><?php echo e(__('main.about_create_5')); ?></li>
                        <li><?php echo e(__('main.about_create_6')); ?></li>
                        <li><?php echo e(__('main.about_create_7')); ?></li>
                        <li><?php echo e(__('main.about_create_8')); ?></li>
                        <li><?php echo e(__('main.about_create_9')); ?></li>
                    </ul>
                    <a href="#" class="btn btn-primary mt-4 px-4 py-2" style="background:#223257; border:none; border-radius:9px; font-size:0.97rem; font-weight:700; letter-spacing:0.7px;">
                        <?php echo e(__('main.about_read_more')); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CSS خاص بتحسين الخط والتدرجات (يُضاف مرة واحدة في رأس الصفحة أو ملف CSS عام) -->
<style>
    .about-section h1, .about-section h2, .about-section h3, .about-section h4, .about-section .fw-bold {
        font-family: 'Poppins', 'Tajawal', Arial, sans-serif;
        letter-spacing: -0.6px;
    }
    .about-section ul {
        margin-bottom: 0;
    }
    .about-create-card ul li {
        margin-bottom: 7px;
        line-height: 1.65;
    }
    .about-section .btn-primary {
        background: #223257;
        border: none;
        border-radius: 9px;
        box-shadow: 0 2px 14px #22325718;
        transition: background 0.16s;
    }
    .about-section .btn-primary:hover {
        background: #182041;
    }
</style>





<section class="industries-section py-5" style="background: #f7f9fc;">
    <div class="container-xxl">
        <div class="row gx-5">

            <!-- Grid -->
            <div class="col-lg-12">
                <div class="row g-4">

                            <!-- Title & Description -->
            <div class="col-md-6 col-xl-4">
                <h2 class="fw-bold" style="color:#223257;letter-spacing:-0.5px; font-size:2.5rem;line-height:1.12;"><?php echo e(__('main.industries_title')); ?></h2>
                <div class="text-muted mt-3" style="font-size:1.4rem;line-height:1.5;max-width:340px;"><?php echo e(__('main.industries_lead')); ?></div>
            </div>

                    <!-- Item 1 -->
                    <div class="col-md-6 col-xl-4">
                        <div class="industry-card industry-card-hover h-100 px-4 py-4">
                            <div class="industry-num"><?php echo e(__('main.industry_01_num')); ?></div>
                            <div class="industry-title"><?php echo e(__('main.industry_01_title')); ?></div>
                            <div class="industry-desc"><?php echo e(__('main.industry_01_desc')); ?></div>
                        </div>
                    </div>
                    <!-- Item 2 (Active) -->
                    <div class="col-md-6 col-xl-4">
                        <div class="industry-card industry-active h-100 px-4 py-4">
                            <div class="industry-num"><?php echo e(__('main.industry_02_num')); ?></div>
                            <div class="industry-title"><?php echo e(__('main.industry_02_title')); ?></div>
                            <div class="industry-desc"><?php echo e(__('main.industry_02_desc')); ?></div>
                        </div>
                    </div>
                    <!-- Item 3 -->
                    <div class="col-md-6 col-xl-4">
                        <div class="industry-card industry-card-hover h-100 px-4 py-4">
                            <div class="industry-num"><?php echo e(__('main.industry_03_num')); ?></div>
                            <div class="industry-title"><?php echo e(__('main.industry_03_title')); ?></div>
                            <div class="industry-desc"><?php echo e(__('main.industry_03_desc')); ?></div>
                        </div>
                    </div>
                    <!-- Item 4 -->
                    <div class="col-md-6 col-xl-4">
                        <div class="industry-card industry-card-hover h-100 px-4 py-4">
                            <div class="industry-num"><?php echo e(__('main.industry_04_num')); ?></div>
                            <div class="industry-title"><?php echo e(__('main.industry_04_title')); ?></div>
                            <div class="industry-desc"><?php echo e(__('main.industry_04_desc')); ?></div>
                        </div>
                    </div>
                    <!-- Item 5 -->
                    <div class="col-md-6 col-xl-4">
                        <div class="industry-card industry-card-hover h-100 px-4 py-4">
                            <div class="industry-num"><?php echo e(__('main.industry_05_num')); ?></div>
                            <div class="industry-title"><?php echo e(__('main.industry_05_title')); ?></div>
                            <div class="industry-desc"><?php echo e(__('main.industry_05_desc')); ?></div>
                        </div>
                    </div>
                    <!-- Item 6 -->
                    <div class="col-md-6 col-xl-4">
                        <div class="industry-card industry-card-hover h-100 px-4 py-4">
                            <div class="industry-num"><?php echo e(__('main.industry_06_num')); ?></div>
                            <div class="industry-title"><?php echo e(__('main.industry_06_title')); ?></div>
                            <div class="industry-desc"><?php echo e(__('main.industry_06_desc')); ?></div>
                        </div>
                    </div>
                    <!-- Item 7 -->
                    <div class="col-md-6 col-xl-4">
                        <div class="industry-card industry-card-hover h-100 px-4 py-4">
                            <div class="industry-num"><?php echo e(__('main.industry_07_num')); ?></div>
                            <div class="industry-title"><?php echo e(__('main.industry_07_title')); ?></div>
                            <div class="industry-desc"><?php echo e(__('main.industry_07_desc')); ?></div>
                        </div>
                    </div>
                    <!-- Item 8 -->
                    <div class="col-md-6 col-xl-4">
                        <div class="industry-card industry-card-hover h-100 px-4 py-4">
                            <div class="industry-num"><?php echo e(__('main.industry_08_num')); ?></div>
                            <div class="industry-title"><?php echo e(__('main.industry_08_title')); ?></div>
                            <div class="industry-desc"><?php echo e(__('main.industry_08_desc')); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CSS احترافي 100% مطابق لفجما -->
<style>
.industry-card {
    background: #fff;
    border-radius: 19px;
    box-shadow: 0 4px 36px #22325712;
    min-height: 360px;
    transition: all .2s cubic-bezier(.45,.05,.55,1.12);
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    gap: 8px;
}
.industry-card .industry-num {
    font-size: 3.5rem;
    font-weight: 700;
    color: #223257;
    letter-spacing: 0.02em;
    line-height: 1;
    margin: 5px;
    padding-top:15px;
}
.industry-card .industry-title {
    font-size: 1.8rem;
    font-weight: 700;
    color: #1c2236;
    margin-bottom: 5px;
    line-height: 1.23;
}
.industry-card .industry-desc {
    font-size: 1.3rem;
    color: #4b5877;
    font-weight: 400;
    margin-top: 5px;
    line-height: 1.54;
}
.industry-active, .industry-card-hover:hover {
    background: #223257 !important;
    color: #fff !important;
    box-shadow: 0 4px 36px #22325732;
}
.industry-active .industry-num,
.industry-card-hover:hover .industry-num {
    color: #fff !important;
}
.industry-active .industry-title,
.industry-card-hover:hover .industry-title {
    color: #fff !important;
}
.industry-active .industry-desc,
.industry-card-hover:hover .industry-desc {
    color: #dee2ee !important;
}
@media (max-width: 991px) {
    .industry-card { min-height: 160px; }
    .industry-card .industry-title { font-size: 1rem;}
    .industry-card .industry-desc { font-size: 0.96rem;}
}
</style>












<!-- Swiper CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

<div class="client-logos-section py-3" style="background: #fff;">
    <div class="container">
        <div class="swiper client-logos-swiper">
            <div class="swiper-wrapper align-items-center">
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/chery.png')); ?>" alt="Chery" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/lexus.png')); ?>" alt="Lexus" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/rasalhamra.png')); ?>" alt="Ras Al Hamra" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/hyundai.png')); ?>" alt="Hyundai" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/ooredoo.png')); ?>" alt="Ooredoo" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/bankmuscat.png')); ?>" alt="Bank Muscat" class="client-logo"></div>
                <div class="swiper-slide"><img src="<?php echo e(asset('images/clients/ford.png')); ?>" alt="Ford" class="client-logo"></div>
                <!-- أضف المزيد إذا احتجت -->
            </div>
        </div>
    </div>
</div>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const isRTL = document.documentElement.dir === 'rtl';

    new Swiper('.client-logos-swiper', {
        slidesPerView: 5,
        spaceBetween: 40,
        loop: true,
        speed: 650,
        autoplay: {
            delay: 1600,
            disableOnInteraction: false,
        },
        breakpoints: {
            0:   { slidesPerView: 2, spaceBetween: 16 },
            520: { slidesPerView: 3, spaceBetween: 18 },
            768: { slidesPerView: 4, spaceBetween: 28 },
            992: { slidesPerView: 5, spaceBetween: 40 },
        },
        grabCursor: true,
        rtl: isRTL,
        allowTouchMove: true,
        // لا تحتاج arrows في هذا التصميم
    });
});
</script>

<style>
.client-logos-section {
    border-bottom: 1.2px solid #efefef;
    margin-bottom: 10px;
}
.client-logo {
    height: 50px;
    width: auto;
    max-width: 135px;
    object-fit: contain;
    filter: grayscale(100%);
    opacity: 0.86;
    transition: opacity .18s;
    display: block;
    margin: 0 auto;
    padding: 0 10px;
}
.client-logo:hover {
    opacity: 1;
    filter: grayscale(0%);
}
.swiper.client-logos-swiper {
    padding: 8px 0;
}
.swiper-slide {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 65px;
}
@media (max-width: 520px) {
    .client-logo { height: 38px; }
    .swiper-slide { height: 48px; }
}
</style>










<section class="services-section py-5">
    <div class="container text-center">
        <h2 class="fw-bold mb-2" style="color:#223257;letter-spacing:-1px;"><?php echo e(__('main.services_title')); ?></h2>
        <div class="mb-4" style="color:#595959; font-size:1.07rem;">
            <?php echo e(__('main.services_lead')); ?>

        </div>

        <!-- الشبكة الرئيسية -->
        <div class="row justify-content-center g-4 mb-3">
            <!-- أول صف: 2 عناصر كبار -->
            <div class="col-md-4">
                <div class="service-card h-100 d-flex flex-column justify-content-between">
                    <img src="<?php echo e(asset('images/ooh.png')); ?>" class="service-img mb-0" alt="">
                    <div class="d-flex align-items-center justify-content-between px-2 py-3" style="min-height:46px;">

                    <div class="service-title m-0"><?php echo e(__('main.service_ooh')); ?></div>
                        <a href="#" class="service-arrow d-flex align-items-center justify-content-center ms-2">
                            <span style="font-size:1.15rem;display:inline-block;">&rarr;</span>
                        </a>
                     </div></div>
            </div>
            
            <div class="col-md-4">
                <div class="service-card h-100 d-flex flex-column justify-content-between">
                    <img src="<?php echo e(asset('images/branding.png')); ?>" class="service-img mb-0" alt="">
                    <div class="d-flex align-items-center justify-content-between px-2 py-3" style="min-height:46px;">
                        <div class="service-title m-0"><?php echo e(__('main.service_branding')); ?></div>
                        <a href="#" class="service-arrow d-flex align-items-center justify-content-center ms-2">
                            <span style="font-size:1.15rem;display:inline-block;">&rarr;</span>
                        </a>
                    </div>
                </div>
            </div>


        </div>

        <!-- بقية الخدمات: شبكة 4 أعمدة لحد الشاشات الصغيرة -->
        <div class="row g-4 justify-content-center">
            <?php
                $services = [
                    [
                        'img' => 'interior.jpg',
                        'title' => __('main.service_interior'),
                    ],
                    [
                        'img' => 'digital-marketing.jpg',
                        'title' => __('main.service_digital'),
                    ],
                    [
                        'img' => 'video.jpg',
                        'title' => __('main.service_video'),
                    ],
                    [
                        'img' => 'gifts.jpg',
                        'title' => __('main.service_gifts'),
                    ],
                    [
                        'img' => 'web.jpg',
                        'title' => __('main.service_web'),
                    ],
                    [
                        'img' => 'events.jpg',
                        'title' => __('main.service_events'),
                    ],
                    [
                        'img' => 'game.jpg',
                        'title' => __('main.service_game'),
                    ],
                    [
                        'img' => 'permits.jpg',
                        'title' => __('main.service_permits'),
                    ],
                ];
            ?>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="service-card h-100 d-flex flex-column align-items-center justify-content-between">
                    <img src="<?php echo e(asset('images/services/'.$srv['img'])); ?>" class="service-img mb-2" alt="">
                    <div class="service-title mb-2"><?php echo e($srv['title']); ?></div>
                    <a href="#" class="service-arrow"><span>&rarr;</span></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- زر See All -->
        <div class="pt-4">
            <a href="#" class="see-all-btn btn btn-dark px-4 rounded-3" style="background:#223257;border:none;font-size:0.95rem;"><?php echo e(__('main.see_all')); ?></a>
        </div>
    </div>
</section>

<style>
.services-section { background: #fff; }
.service-card {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 4px 20px #22325714;
    padding: 12px 10px 14px 10px;
    min-height: 408px;
    transition: box-shadow .19s, transform .14s;
    border: 1.2px solid #f2f3fa;
    position: relative;
}
.service-card:hover {
    box-shadow: 0 8px 32px #22325724;
    transform: translateY(-4px) scale(1.02);
    border-color: #22325715;
}
.service-img {
    width: 100%;
    height: 301.49px;
    object-fit: cover;
    border-radius: 13px;
    margin-bottom: 8px;
    background: #f7f7fa;
    box-shadow: 0 2px 10px #22325709;
}
.service-title {
    font-weight: 500;
    color: #223257;
    font-size: 1.09rem;
    text-align: center;
}
.service-arrow {
   color: #223257;
    font-size: 1.17rem;
    background: transparent;
    border: none;
    transition: color .12s;
    text-decoration: none;
    margin-left: 4px;
    margin-right: 0;
    min-width: 26px;
    min-height: 26px;
}
.service-card:hover .service-arrow {
    color: #61d2ff;
}
.service-card:hover {
    box-shadow: 0 8px 32px #22325724;
    transform: translateY(-4px) scale(1.018);
    border-color: #22325715;
}
.see-all-btn {
    min-width: 130px;
    border-radius: 8px;
    font-size: 0.98rem;
    font-weight: 600;
    letter-spacing: 0.02em;
    background: #223257;
    color: #fff;
}
@media (max-width: 991px) {
    .service-img { height: 90px; }
    .service-card { min-height: 200px; }
}
@media (max-width: 575px) {
    .service-img { height: 60px; }
    .service-card { min-height: 120px; }
    .service-title { font-size: 0.96rem; }
}
</style>





<?php
$members = [
    ['name' => 'team_1_name', 'title' => 'team_1_title'],
    ['name' => 'team_2_name', 'title' => 'team_2_title'],
    ['name' => 'team_3_name', 'title' => 'team_3_title'],
    ['name' => 'team_4_name', 'title' => 'team_4_title'],
    ['name' => 'team_5_name', 'title' => 'team_5_title'],
    ['name' => 'team_6_name', 'title' => 'team_6_title'],
];
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
<div >
<div class="team-section py-5" style="background: #f7f9fb;">
  <div class="container position-relative">
    <h2 class="fw-bold mb-4" style="color:#34406C;letter-spacing:-1.2px;"><?php echo e(__('main.meet_team')); ?></h2>
    <div class="swiper team-expansion-swiper">
      <div class="swiper-wrapper">
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="swiper-slide team-slide">
          <div class="team-img-box">
            <img src="<?php echo e(url('images/team/team' . ($i+1) . '.png')); ?>" class="img-fluid" alt="">
            <div class="team-overlay">
              <div class="team-name"><?php echo e(__('main.' . $member['name'])); ?></div>
              <div class="team-title"><?php echo e(__('main.' . $member['title'])); ?></div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="team-swiper-nav">
        <button class="swiper-button-prev"></button>
        <button class="swiper-button-next"></button>
      </div>
    </div>
  </div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<style>
.team-section {
  background: #f7f9fb;
  padding-top: 56px;
  padding-bottom: 56px;
  overflow-x: hidden;
}

.team-expansion-swiper .swiper-wrapper {
  align-items: flex-end;
}

.team-slide {
  /* كارد ضيق افتراضي */
  width: 162px !important;
  max-width: 162px;
  min-width: 162px;
  transition: all 0.41s cubic-bezier(.75,.07,.29,1.01);
  border-radius: 15px;
  overflow: hidden;
  position: relative;
  box-shadow: 0 2px 22px #23234314;
  cursor: pointer;
  z-index: 1;
}
.team-slide.active,
.team-slide.swiper-slide-active {
  /* الكارد المفتوح */
  width: 465px !important;
  min-width: 465px;
  max-width: 465px;
  z-index: 2;
  box-shadow: 0 8px 46px #22325718;
}
.team-img-box {
  height: 410px;
  min-width: 100%;
  display: flex;
  align-items: flex-end;
  position: relative;
  border-radius: 15px;
  overflow: hidden;
  background: #f6f7fb;
}
.team-img-box img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 15px;
  transition: filter 0.25s, transform 0.44s cubic-bezier(.55,1.13,.36,1.07);
  filter: grayscale(0.08) brightness(0.97);
  will-change: transform, filter;
}
.team-slide:not(.active) .team-img-box img {
  filter: grayscale(0.15) brightness(0.91) blur(0.3px);
  transform: scale(1);
}
.team-slide.active .team-img-box img,
.team-slide.swiper-slide-active .team-img-box img {
  filter: none;
  transform: scale(1.065);
  z-index: 3;
}
.team-overlay {
  display: none;
}
.team-slide.active .team-overlay,
.team-slide.swiper-slide-active .team-overlay {
  display: block;
  position: absolute;
  left: 0; right: 0; bottom: 0;
  background: linear-gradient(0deg,#15192add 90%,#15192a05 100%);
  color: #fff;
  padding: 27px 24px 14px 22px;
  border-radius: 0 0 15px 15px;
}
.team-name { font-size: 1.13rem; font-weight: bold; margin-bottom: 4px; letter-spacing: 0.01em;}
.team-title { font-size: 1.02rem; opacity: 0.84; font-weight: 400; }

.team-swiper-nav {
  position: absolute;
  right: 16px;
  bottom: 14px;
  z-index: 8;
  display: flex;
  gap: 10px;
}
.swiper-button-prev, .swiper-button-next {
  width: 32px; height: 32px;
  border: none;
  border-radius: 50%;
  background: #22325712;
  color: #223257;
  font-size: 1.28rem;
  display: flex; align-items: center; justify-content: center;
  transition: background .15s, color .13s;
  box-shadow: 0 2px 12px #2232570a;
}
.swiper-button-prev:hover, .swiper-button-next:hover {
  background: #223257;
  color: #fff;
}
.swiper-button-prev::after { content: '←'; font-size: 1.18rem; }
.swiper-button-next::after { content: '→'; font-size: 1.18rem; }

@media (max-width: 1199px) {
  .team-slide, .team-slide.active, .team-slide.swiper-slide-active {
    width: 210px !important;
    min-width: 210px;
    max-width: 210px;
  }
  .team-slide.active, .team-slide.swiper-slide-active {
    width: 310px !important;
    min-width: 310px;
    max-width: 310px;
  }
  .team-img-box { height: 210px; }
}
@media (max-width: 767px) {
  .team-slide, .team-slide.active, .team-slide.swiper-slide-active {
    width: 95px !important;
    min-width: 95px;
    max-width: 95px;
  }
  .team-slide.active, .team-slide.swiper-slide-active {
    width: 145px !important;
    min-width: 145px;
    max-width: 145px;
  }
  .team-img-box { height: 105px; }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  var swiper = new Swiper('.team-expansion-swiper', {
    slidesPerView: 'auto',
    spaceBetween: 18,
    centeredSlides: true,
    loop: true,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev'
    }
  });

  // تحديث الكارد الفعّال
  function updateActiveCard() {
    document.querySelectorAll('.team-slide').forEach(function(slide) {
      slide.classList.remove('active');
    });
    let active = document.querySelector('.team-slide.swiper-slide-active');
    if (active) active.classList.add('active');
  }
  swiper.on('slideChangeTransitionEnd', updateActiveCard);
  updateActiveCard();

  // Click لتوسيط الكارد المختار
  document.querySelectorAll('.team-slide').forEach(function(slide, idx) {
    slide.addEventListener('click', function() {
      swiper.slideToLoop(idx, 500);
    });
  });
});
</script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idea\resources\views/temp/temp_preview_yWwbHY2r5s.blade.php ENDPATH**/ ?>