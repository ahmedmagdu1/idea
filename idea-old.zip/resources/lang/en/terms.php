<?php
return [
    'title' => 'Terms & Conditions',
    'last_updated' => 'Last updated',
    'content' => 'This is a placeholder for your Terms & Conditions. You can manage this content later via the CMS or by editing this file.',
];
