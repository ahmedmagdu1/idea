﻿<?php
return [
    'welcome' => 'مرحبا بك!',
    'login'   => 'تسجيل الدخول',
    'logout'  => 'تسجيل الخروج',
];
