﻿<?php

return [
    'hero_title' => 'من نحن',
    'hero_subtitle' => 'مجموعة IDEA هي منظومة تجمع الإبداع والهندسة والاتصال — وتوحد ثلاث شركات متخصصة تحت رؤية واحدة.',
    'title' => 'من نحن',
    'lead' => 'نصنع أفكاراً تغيّر النتائج وتدفع النمو.',

    'aboutus_title' => 'نبذة عن المجموعة',
    'aboutus_lead' => 'مجموعة IDEA هي منظومة تجمع الإبداع والهندسة والاتصال — وتوحد ثلاث شركات متخصصة تحت رؤية واحدة.',
    'mission_text' => 'مهمتنا أن نصوغ أفكاراً تترك بصمتها: في المدينة، وفي الفضاء الرقمي، وفي قلوب الناس. لا ننفّذ مشاريع فحسب، بل نبني حلولاً متكاملة تمزج بين الإعلان الخارجي، والتسويق، وإنتاج الفيديو، وتصميم المساحات، والابتكار.',

    'company_seraj_kicker' => 'IDEA GROUP',
    'company_seraj_title' => 'سراج ميديا',
    'company_seraj_sub' => 'تابعة لـ Oneic Media',
    'company_seraj_description' => 'شركة إعلامية تتعامل مع البيئة الحضرية، نحول المدينة إلى منصة للتواصل مع العلامات التجارية من خلال:',
    'company_seraj_feature_1' => 'إعلانات خارجية عالية التأثير (لوحات، شاشات رقمية، وصيغ مبتكرة)',
    'company_seraj_feature_2' => 'محتوى مرئي مخصص للشاشات الرقمية',
    'company_seraj_feature_3' => 'رسومات ثلاثية الأبعاد متقدمة تخطف الأنظار',
    'company_seraj_tagline' => 'هنا تتحول الإعلانات إلى فن، والتقنية هي اللوحة التي نرسم عليها.',
    'company_seraj_btn' => 'اكتشف المزيد',

    'company_ides_kicker' => 'IDEA GROUP',
    'company_ides_title' => 'آيدز ديزاين',
    'company_ides_sub' => 'تابعة لـ Oneic Media',
    'company_ides_description' => 'استوديو إبداعي متخصص في الهوية البصرية وتجارب العلامات. نصمم حلولاً لافتة:',
    'company_ides_feature_1' => 'تصميم الهوية البصرية والشعارات',
    'company_ides_feature_2' => 'حلول تصميم رقمية ومطبوعة',
    'company_ides_feature_3' => 'تصميم تجربة المستخدم وواجهات الاستخدام',
    'company_ides_tagline' => 'حيث يلتقي الإبداع بالتفكير الاستراتيجي.',

    'company_anmat_kicker' => 'IDEA GROUP',
    'company_anmat_title' => 'أنمات',
    'company_anmat_sub' => 'تابعة لـ Oneic Media',
    'company_anmat_description' => 'شركة تقنية تركّز على الحلول الرقمية المبتكرة. نطور تطبيقات متقدمة:',
    'company_anmat_feature_1' => 'تطبيقات ويب وموبايل مخصصة',
    'company_anmat_feature_2' => 'منصات تجارة إلكترونية وحلول رقمية',
    'company_anmat_feature_3' => 'تحليلات متقدمة وأدوات أتمتة ذكية',
    'company_anmat_tagline' => 'نحوّل الأفكار إلى واقع رقمي.',

    'stats_regions' => '+4 مناطق تشغيل',
    'stats_regions_label' => 'مناطق<br>التشغيل',

    'client_chery_alt' => 'شعار شيري',
    'client_lexus_alt' => 'شعار لكزس',
    'client_rasalhamra_alt' => 'رأس الحمراء',
    'client_hyundai_alt' => 'هيونداي',
    'client_ooredoo_alt' => 'عُمانتل',
    'client_bankmuscat_alt' => 'بنك مسقط',
    'client_ford_alt' => 'فورد',
];
