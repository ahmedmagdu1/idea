@extends('layouts.app')

@section('title', 'Careers')

@section('content')
<section class="hero-section">
  <div class="hero-overlay"></div>
  <img src="https://images.unsplash.com/photo-1484980859177-5ac1249fda6f?q=80&w=1600&auto=format&fit=crop" class="hero-bg" alt="Careers">
  <div class="hero-content">
    <h1 class="hero-title">Careers</h1>
    <p class="hero-description">Join our team to build standout experiences.</p>
  </div>
  </section>

<div class="container py-5">
  <div class="row g-4">
    @forelse($items as $item)
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title mb-1"><a href="{{ url('/careers/'.$item->slug) }}">{{ $item->title }}</a></h5>
            <div class="text-muted small mb-2">{{ $item->location }} @if($item->type) • {{ $item->type }} @endif</div>
            <p class="card-text flex-grow-1">{{ Str::limit($item->excerpt ?: strip_tags($item->body), 120) }}</p>
            <a class="btn btn-brand mt-2" href="{{ url('/careers/'.$item->slug) }}">View role</a>
          </div>
        </div>
      </div>
    @empty
      <div class="col-12 text-center text-muted">No open positions at the moment.</div>
    @endforelse
  </div>
  <div class="mt-4">{{ $items->links() }}</div>
</div>
@endsection

