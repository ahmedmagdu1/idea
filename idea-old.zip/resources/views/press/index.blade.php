@extends('layouts.app')

@section('title', 'Press')

@section('content')
<section class="hero-section">
  <div class="hero-overlay"></div>
  <img src="https://images.unsplash.com/photo-1495020689067-958852a7765e?q=80&w=1600&auto=format&fit=crop" class="hero-bg" alt="Press">
  <div class="hero-content">
    <h1 class="hero-title">Press & Blog</h1>
    <p class="hero-description">Updates, case studies, and stories.</p>
  </div>
  </section>

<div class="container py-5">
  <div class="row g-4">
    @forelse($items as $item)
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title mb-1"><a href="{{ url('/press/'.$item->slug) }}">{{ $item->title }}</a></h5>
            <div class="text-muted small mb-2">{{ optional($item->published_at)->format('M d, Y') }}</div>
            <p class="card-text flex-grow-1">{{ Str::limit($item->excerpt ?: strip_tags($item->body), 140) }}</p>
            <a class="btn btn-brand mt-2" href="{{ url('/press/'.$item->slug) }}">Read more</a>
          </div>
        </div>
      </div>
    @empty
      <div class="col-12 text-center text-muted">No posts yet.</div>
    @endforelse
  </div>
  <div class="mt-4">{{ $items->links() }}</div>
</div>
@endsection

