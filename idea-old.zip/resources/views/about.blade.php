@extends('layouts.app')

@section('title', __('messages.welcome'))

@section('content')

<section class="aboutus-hero position-relative hero soft">
    <img src="{{ asset('images/about-hero.png') }}" class="aboutus-bg-img" alt="">
    <div class="aboutus-overlay"></div>
    <div class="container h-100 d-flex flex-column justify-content-center align-items-center text-center aboutus-hero-content">
        <h1 class="aboutus-title mb-2 hero-title text-white">{{ __('about.aboutus_title') }}</h1>
        <p class="aboutus-lead hero-lead text-white-50">{{ __('about.aboutus_lead') }}</p>
    </div>
</section>

{{--
  <div class="container">
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
      <div>
        <h2 class="mb-1">{{ __('main.aboutus_title') }}</h2>
        <div class="text-muted">IDEA Group • Since 2012</div>
      </div>
      <div class="d-flex align-items-center gap-2 muted">
        <i class="bi bi-patch-check-fill text-primary"></i>
        <span>{{ __('main.aboutus_lead') }}</span>
      </div>
    </div>
  </div>
  --}}




<!-- Swiper CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

<div class="client-logos-section py-4" style="background:#fff;">
    <div class="container">
        <div class="swiper client-logos-swiper">
            <div class="swiper-wrapper align-items-center">
                <div class="swiper-slide"><img src="{{ asset('images/clients/chery.png') }}" alt="Chery" class="client-logo"></div>
                <div class="swiper-slide"><img src="{{ asset('images/clients/lexus.png') }}" alt="Lexus" class="client-logo"></div>
                <div class="swiper-slide"><img src="{{ asset('images/clients/rasalhamra.png') }}" alt="Ras Al Hamra" class="client-logo"></div>
                <div class="swiper-slide"><img src="{{ asset('images/clients/hyundai.png') }}" alt="Hyundai" class="client-logo"></div>
                <div class="swiper-slide"><img src="{{ asset('images/clients/ooredoo.png') }}" alt="Ooredoo" class="client-logo"></div>
                <div class="swiper-slide"><img src="{{ asset('images/clients/bankmuscat.png') }}" alt="Bank Muscat" class="client-logo"></div>
                <div class="swiper-slide"><img src="{{ asset('images/clients/ford.png') }}" alt="Ford" class="client-logo"></div>
                <!-- أضف المزيد إذا احتجت -->
            </div>
        </div>
    </div>
</div>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const isRTL = document.documentElement.dir === 'rtl';

    new Swiper('.client-logos-swiper', {
        slidesPerView: 5,
        spaceBetween: 40,
        loop: true,
        speed: 650,
        autoplay: {
            delay: 1600,
            disableOnInteraction: false,
        },
        breakpoints: {
            0:   { slidesPerView: 2, spaceBetween: 16 },
            520: { slidesPerView: 3, spaceBetween: 18 },
            768: { slidesPerView: 4, spaceBetween: 28 },
            992: { slidesPerView: 5, spaceBetween: 40 },
        },
        grabCursor: true,
        rtl: isRTL,
        allowTouchMove: true,
        // لا تحتاج arrows في هذا التصميم
    });
});
</script>

<!-- styles moved to theme.css -->



<section class="aboutus-desc section-about">
  <div class="container">
    <!-- Mission Statement -->
<!-- Mission block (matches About page design) -->
<section class="section-about">
  <div class="container pt-4">
    <div class="aboutus-mission text-center mb-5 mission-copy">
      <p>Our mission is to craft ideas that leave a mark: in the city, in the digital space, and in people's hearts.</p>
      <p>We don’t just deliver projects — we build holistic solutions that merge outdoor advertising, marketing, video production, spatial design, and innovation.</p>
    </div>
    <hr class="my-5" style="opacity:.15">
  </div>
 </section>

    <!-- Company Pills/Cards -->
    <div class="aboutus-tabs d-flex justify-content-center flex-wrap gap-3 mb-5">
      <a href="#" class="aboutus-pill active" data-company="seraj">
        <span class="pill-kicker">IDEA GROUP</span>
        <span class="pill-title">Seraj Media</span>
        <span class="pill-sub">by Oneic Media</span>
      </a>
      <a href="#" class="aboutus-pill" data-company="ides">
        <span class="pill-kicker">IDEA GROUP</span>
        <span class="pill-title">Ides Design</span>
        <span class="pill-sub">by Oneic Media</span>
      </a>
      <a href="#" class="aboutus-pill" data-company="anmat">
        <span class="pill-kicker">IDEA GROUP</span>
        <span class="pill-title">Anmat</span>
        <span class="pill-sub">by Oneic Media</span>
      </a>
    </div>

    <!-- Main Content Area -->
    <div class="row g-5 align-items-stretch">
      <!-- Left: Company Info Box -->
      <div class="col-lg-5 col-xl-5">
        <div class="aboutus-casebox h-100">
          <div class="case-header mb-4">
            <div class="aboutus-case-logo mb-3">
              <img src="{{ asset('images/seraj.png') }}" alt="Seraj" class="company-logo">
            </div>
            <h3 class="aboutus-case-title case-title">
              Outdoor Advertising, Video Production, 3D Content
            </h3>
          </div>

          <div class="case-body">
            <p class="aboutus-case-desc case-desc">
              A media company that works with the urban environment. We turn the city into a platform for brand communication through:
            </p>

            <ul class="case-features">
              <li>High-impact outdoor advertising (billboards, digital screens, unconventional formats)</li>
              <li>Video content for digital displays</li>
              <li>Cutting-edge 3D animations that stop people in their tracks</li>
            </ul>

            <p class="case-tagline">
              Here, advertising becomes art — and technology is its canvas.
            </p>

            <a href="#" class="btn aboutus-cta">
              <span>{{ __('main.case_btn') ?: 'EXPLORE MORE' }}</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </a>
          </div>
        </div>
      </div>

      <!-- Right: Visual Grid -->

                        <div class="col-lg-7 col-xl-7">
                        <div class="aboutus-visual-grid">
                            <div class="grid-item large-rect top placeholder"></div>
                            <div class="grid-item large-rect middle placeholder"></div>
                            <div class="grid-item stats-card">
                                <div class="stats-content">
                                    <div class="stats-number">+4</div>
                                    <div class="stats-label">Operating<br>Regions</div>
                                </div>
                            </div>
                            <div class="grid-item large-rect bottom placeholder with-inset"></div>
                        </div>
                    </div>

    </div>
  </div>
</section>
<br>
<br>
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Company data for switching content
  const companyData = {
    seraj: {
      logo: '{{ asset("images/seraj.png") }}',
      title: 'Outdoor Advertising, Video Production, 3D Content',
      description: 'A media company that works with the urban environment. We turn the city into a platform for brand communication through:',
      features: [
        'High-impact outdoor advertising (billboards, digital screens, unconventional formats)',
        'Video content for digital displays',
        'Cutting-edge 3D animations that stop people in their tracks'
      ],
      tagline: 'Here, advertising becomes art — and technology is its canvas.'
    },
    ides: {
      logo: '{{ asset("images/ides.png") }}',
      title: 'Creative Design & Brand Identity',
      description: 'A creative studio specializing in visual identity and brand experiences. We craft memorable designs that:',
      features: [
        'Brand identity and logo design',
        'Digital and print design solutions',
        'User experience and interface design'
      ],
      tagline: 'Where creativity meets strategic thinking.'
    },
    anmat: {
      logo: '{{ asset("images/anmat.png") }}',
      title: 'Digital Solutions & Technology',
      description: 'A technology company focused on innovative digital solutions. We develop cutting-edge applications that:',
      features: [
        'Custom web and mobile applications',
        'E-commerce and digital platforms',
        'Advanced analytics and automation tools'
      ],
      tagline: 'Transforming ideas into digital reality.'
    }
  };

  // Handle pill switching
  document.querySelectorAll('.aboutus-pill').forEach(pill => {
    pill.addEventListener('click', function(e) {
      e.preventDefault();

      // Update active state
      document.querySelectorAll('.aboutus-pill').forEach(p => p.classList.remove('active'));
      this.classList.add('active');

      // Get company data
      const company = this.dataset.company;
      const data = companyData[company];

      if (data) {
        // Update content with smooth transition
        const caseBox = document.querySelector('.aboutus-casebox');
        caseBox.style.opacity = '0.7';
        caseBox.style.transform = 'translateY(10px)';

        setTimeout(() => {
          // Update logo
          document.querySelector('.company-logo').src = data.logo;

          // Update title
          document.querySelector('.case-title').textContent = data.title;

          // Update description
          document.querySelector('.case-desc').textContent = data.description;

          // Update features list
          const featuresList = document.querySelector('.case-features');
          featuresList.innerHTML = data.features.map(feature => `<li>${feature}</li>`).join('');

          // Update tagline
          document.querySelector('.case-tagline').textContent = data.tagline;

          // Restore animation
          caseBox.style.opacity = '1';
          caseBox.style.transform = 'translateY(0)';
        }, 200);
      }
    });
  });

  // Add scroll animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);

  // Observe elements for animation
  document.querySelectorAll('.aboutus-pill, .aboutus-casebox, .grid-item').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
  });
});
</script>


@endsection
