@extends('layouts.app')
@section('title', 'Terms & Conditions')
@section('content')
<div class="container py-5">
  <h1>Terms & Conditions</h1>
  <p class="text-muted">Last updated: {{ date('Y') }}</p>
  <p>This is a placeholder for your Terms & Conditions. You can manage this content later via the CMS or by editing this file.</p>
</div>
@endsection

