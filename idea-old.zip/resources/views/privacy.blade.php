@extends('layouts.app')
@section('title', 'Privacy Policy')
@section('content')
<div class="container py-5">
  <h1>Privacy Policy</h1>
  <p class="text-muted">Last updated: {{ date('Y') }}</p>
  <p>This is a placeholder for your Privacy Policy. You can manage this content later via the CMS or by editing this file.</p>
</div>
@endsection

